import { manufacturers } from "./manufacturers";

export interface StateInfo {
  slug: string;
  name: string;
  abbreviation: string;
  housingAgency: string;
  region: "Northeast" | "Midwest" | "South" | "West";
  marketNote: string;
}

// Housing finance agency names are the real, publicly known state agencies.
// Down-payment-assistance amounts change yearly by program, so state pages
// intentionally avoid quoting specific dollar figures as fixed facts and
// instead point buyers to their matched lender for current numbers.
const rawStates: StateInfo[] = [
  { slug: "alabama", name: "Alabama", abbreviation: "AL", housingAgency: "Alabama Housing Finance Authority", region: "South", marketNote: "moderate lending market" },
  { slug: "alaska", name: "Alaska", abbreviation: "AK", housingAgency: "Alaska Housing Finance Corporation", region: "West", marketNote: "limited-competition market" },
  { slug: "arizona", name: "Arizona", abbreviation: "AZ", housingAgency: "Arizona Department of Housing", region: "West", marketNote: "high-growth market" },
  { slug: "arkansas", name: "Arkansas", abbreviation: "AR", housingAgency: "Arkansas Development Finance Authority", region: "South", marketNote: "affordable entry market" },
  { slug: "california", name: "California", abbreviation: "CA", housingAgency: "California Housing Finance Agency (CalHFA)", region: "West", marketNote: "high-demand coastal market" },
  { slug: "colorado", name: "Colorado", abbreviation: "CO", housingAgency: "Colorado Housing and Finance Authority", region: "West", marketNote: "competitive mountain-region market" },
  { slug: "connecticut", name: "Connecticut", abbreviation: "CT", housingAgency: "Connecticut Housing Finance Authority", region: "Northeast", marketNote: "established Northeast market" },
  { slug: "delaware", name: "Delaware", abbreviation: "DE", housingAgency: "Delaware State Housing Authority", region: "Northeast", marketNote: "compact, stable market" },
  { slug: "florida", name: "Florida", abbreviation: "FL", housingAgency: "Florida Housing Finance Corporation", region: "South", marketNote: "high-growth market" },
  { slug: "georgia", name: "Georgia", abbreviation: "GA", housingAgency: "Georgia Department of Community Affairs", region: "South", marketNote: "fast-growing market" },
  { slug: "hawaii", name: "Hawaii", abbreviation: "HI", housingAgency: "Hawaii Housing Finance and Development Corporation", region: "West", marketNote: "high-cost island market" },
  { slug: "idaho", name: "Idaho", abbreviation: "ID", housingAgency: "Idaho Housing and Finance Association", region: "West", marketNote: "fast-growing market" },
  { slug: "illinois", name: "Illinois", abbreviation: "IL", housingAgency: "Illinois Housing Development Authority", region: "Midwest", marketNote: "diverse statewide market" },
  { slug: "indiana", name: "Indiana", abbreviation: "IN", housingAgency: "Indiana Housing and Community Development Authority", region: "Midwest", marketNote: "manufacturing-hub market" },
  { slug: "iowa", name: "Iowa", abbreviation: "IA", housingAgency: "Iowa Finance Authority", region: "Midwest", marketNote: "affordable entry market" },
  { slug: "kansas", name: "Kansas", abbreviation: "KS", housingAgency: "Kansas Housing Resources Corporation", region: "Midwest", marketNote: "affordable entry market" },
  { slug: "kentucky", name: "Kentucky", abbreviation: "KY", housingAgency: "Kentucky Housing Corporation", region: "South", marketNote: "affordable entry market" },
  { slug: "louisiana", name: "Louisiana", abbreviation: "LA", housingAgency: "Louisiana Housing Corporation", region: "South", marketNote: "hurricane-resilient building market" },
  { slug: "maine", name: "Maine", abbreviation: "ME", housingAgency: "MaineHousing", region: "Northeast", marketNote: "rural-friendly market" },
  { slug: "maryland", name: "Maryland", abbreviation: "MD", housingAgency: "Maryland Department of Housing and Community Development", region: "Northeast", marketNote: "moderate lending market" },
  { slug: "massachusetts", name: "Massachusetts", abbreviation: "MA", housingAgency: "MassHousing", region: "Northeast", marketNote: "high-demand market" },
  { slug: "michigan", name: "Michigan", abbreviation: "MI", housingAgency: "Michigan State Housing Development Authority", region: "Midwest", marketNote: "manufacturing-hub market" },
  { slug: "minnesota", name: "Minnesota", abbreviation: "MN", housingAgency: "Minnesota Housing Finance Agency", region: "Midwest", marketNote: "moderate lending market" },
  { slug: "mississippi", name: "Mississippi", abbreviation: "MS", housingAgency: "Mississippi Home Corporation", region: "South", marketNote: "affordable entry market" },
  { slug: "missouri", name: "Missouri", abbreviation: "MO", housingAgency: "Missouri Housing Development Commission", region: "Midwest", marketNote: "affordable entry market" },
  { slug: "montana", name: "Montana", abbreviation: "MT", housingAgency: "Montana Housing", region: "West", marketNote: "rural-friendly market" },
  { slug: "nebraska", name: "Nebraska", abbreviation: "NE", housingAgency: "Nebraska Investment Finance Authority", region: "Midwest", marketNote: "affordable entry market" },
  { slug: "nevada", name: "Nevada", abbreviation: "NV", housingAgency: "Nevada Housing Division", region: "West", marketNote: "fast-growing market" },
  { slug: "new-hampshire", name: "New Hampshire", abbreviation: "NH", housingAgency: "New Hampshire Housing Finance Authority", region: "Northeast", marketNote: "established Northeast market" },
  { slug: "new-jersey", name: "New Jersey", abbreviation: "NJ", housingAgency: "New Jersey Housing and Mortgage Finance Agency", region: "Northeast", marketNote: "moderate lending market" },
  { slug: "new-mexico", name: "New Mexico", abbreviation: "NM", housingAgency: "New Mexico Mortgage Finance Authority", region: "West", marketNote: "rural-friendly market" },
  { slug: "new-york", name: "New York", abbreviation: "NY", housingAgency: "State of New York Mortgage Agency (SONYMA)", region: "Northeast", marketNote: "high-demand market" },
  { slug: "north-carolina", name: "North Carolina", abbreviation: "NC", housingAgency: "North Carolina Housing Finance Agency", region: "South", marketNote: "fast-growing market" },
  { slug: "north-dakota", name: "North Dakota", abbreviation: "ND", housingAgency: "North Dakota Housing Finance Agency", region: "Midwest", marketNote: "limited-competition market" },
  { slug: "ohio", name: "Ohio", abbreviation: "OH", housingAgency: "Ohio Housing Finance Agency", region: "Midwest", marketNote: "affordable entry market" },
  { slug: "oklahoma", name: "Oklahoma", abbreviation: "OK", housingAgency: "Oklahoma Housing Finance Agency", region: "South", marketNote: "affordable entry market" },
  { slug: "oregon", name: "Oregon", abbreviation: "OR", housingAgency: "Oregon Housing and Community Services", region: "West", marketNote: "high-demand market" },
  { slug: "pennsylvania", name: "Pennsylvania", abbreviation: "PA", housingAgency: "Pennsylvania Housing Finance Agency", region: "Northeast", marketNote: "modular-manufacturing hub market" },
  { slug: "rhode-island", name: "Rhode Island", abbreviation: "RI", housingAgency: "RIHousing", region: "Northeast", marketNote: "compact, stable market" },
  { slug: "south-carolina", name: "South Carolina", abbreviation: "SC", housingAgency: "SC Housing", region: "South", marketNote: "fast-growing market" },
  { slug: "south-dakota", name: "South Dakota", abbreviation: "SD", housingAgency: "South Dakota Housing Development Authority", region: "Midwest", marketNote: "limited-competition market" },
  { slug: "tennessee", name: "Tennessee", abbreviation: "TN", housingAgency: "Tennessee Housing Development Agency", region: "South", marketNote: "moderate lending market" },
  { slug: "texas", name: "Texas", abbreviation: "TX", housingAgency: "Texas Department of Housing and Community Affairs", region: "South", marketNote: "high-growth market" },
  { slug: "utah", name: "Utah", abbreviation: "UT", housingAgency: "Utah Housing Corporation", region: "West", marketNote: "fast-growing market" },
  { slug: "vermont", name: "Vermont", abbreviation: "VT", housingAgency: "Vermont Housing Finance Agency", region: "Northeast", marketNote: "rural-friendly market" },
  { slug: "virginia", name: "Virginia", abbreviation: "VA", housingAgency: "Virginia Housing", region: "South", marketNote: "moderate lending market" },
  { slug: "washington", name: "Washington", abbreviation: "WA", housingAgency: "Washington State Housing Finance Commission", region: "West", marketNote: "high-demand market" },
  { slug: "west-virginia", name: "West Virginia", abbreviation: "WV", housingAgency: "West Virginia Housing Development Fund", region: "South", marketNote: "affordable entry market" },
  { slug: "wisconsin", name: "Wisconsin", abbreviation: "WI", housingAgency: "Wisconsin Housing and Economic Development Authority", region: "Midwest", marketNote: "moderate lending market" },
  { slug: "wyoming", name: "Wyoming", abbreviation: "WY", housingAgency: "Wyoming Community Development Authority", region: "West", marketNote: "limited-competition market" },
  { slug: "washington-dc", name: "Washington, D.C.", abbreviation: "DC", housingAgency: "DC Housing Finance Agency", region: "Northeast", marketNote: "high-demand urban market" },
];

export const states: StateInfo[] = rawStates.sort((a, b) => a.name.localeCompare(b.name));

export function getStateBySlug(slug: string): StateInfo | undefined {
  return states.find((state) => state.slug === slug);
}

/** Deterministic pseudo-random pick of manufacturers serving a given state. */
export function manufacturersForState(slug: string): typeof manufacturers {
  const seed = slug.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const rotated = [...manufacturers.slice(seed % manufacturers.length), ...manufacturers.slice(0, seed % manufacturers.length)];
  return rotated.slice(0, 3);
}
