export interface ResourceSection {
  heading: string;
  body: string[];
}

export interface Resource {
  slug: string;
  title: string;
  description: string;
  author: string;
  publishedAt: string;
  readMinutes: number;
  category: string;
  sections: ResourceSection[];
}

export const resources: Resource[] = [
  {
    slug: "modular-home-cost-guide",
    title: "Modular Home Costs: Complete Financing & Price Guide",
    description:
      "A comprehensive breakdown of modular home costs — base price, site work, transportation, and total financing requirements.",
    author: "Michael Chen",
    publishedAt: "2026-01-26",
    readMinutes: 9,
    category: "Cost Guides",
    sections: [
      {
        heading: "What drives the base price",
        body: [
          "A modular home's factory price is quoted per square foot and typically ranges from $80 to $220 depending on finish level, floor plan complexity, and manufacturer. That figure covers the factory-built modules only — it excludes land, foundation, delivery, and site work.",
          "Premium and architect-designed builders price meaningfully higher because of custom glazing, higher-end cabinetry, and net-zero energy packages, while entry-level manufacturers keep costs down through standardized floor plans and higher production volume.",
        ],
      },
      {
        heading: "Site work and delivery add-ons",
        body: [
          "Beyond the factory price, buyers should budget for foundation work, utility hookups, permits, and crane-assisted module placement. Delivery distance from the factory to your site is one of the biggest cost swings — some manufacturers only serve a few hundred miles from their plant.",
          "A realistic all-in budget adds 25–45% on top of the base factory price once land development, permitting, and finishing work are included.",
        ],
      },
      {
        heading: "How financing changes the total cost",
        body: [
          "Because modular homes are financed in stages — deposit, production, delivery, completion — the loan structure itself affects total cost through interest-only construction periods and draw-schedule fees. Choosing a lender who understands modular draw schedules avoids unnecessary inspection delays that extend the interest-only period.",
          "Modular homes typically cost 10–20% less than a comparable site-built home once construction efficiency and reduced labor waste are factored in.",
        ],
      },
    ],
  },
  {
    slug: "green-mortgage-guide",
    title: "Green Mortgages for Energy-Efficient Prefab Homes",
    description:
      "How energy-efficient modular construction can qualify you for green mortgage discounts and lower long-term costs.",
    author: "Priya Raman",
    publishedAt: "2026-02-03",
    readMinutes: 7,
    category: "Financing 101",
    sections: [
      {
        heading: "What qualifies as a green mortgage",
        body: [
          "Green mortgage programs offer rate discounts, higher borrowing limits, or reduced fees for homes that meet a recognized energy-efficiency standard — such as ENERGY STAR certification, HERS index scores, or net-zero design.",
          "Modular construction is well suited to these programs because factory-controlled building envelopes typically achieve tighter air sealing and more consistent insulation than site-built framing.",
        ],
      },
      {
        heading: "Lenders that specialize in green programs",
        body: [
          "Not every lender offers green mortgage products, and fewer still understand how to apply them to modular construction draw schedules. Matching with a lender who actively originates energy-efficient mortgages avoids having to educate an unfamiliar underwriter mid-transaction.",
        ],
      },
      {
        heading: "Documentation you'll need",
        body: [
          "Expect to provide the manufacturer's energy specification sheet, a HERS rater report if available, and appliance/system energy ratings. Some programs require the rating to be ordered before the appraisal so the energy value can be included in underwriting.",
        ],
      },
    ],
  },
  {
    slug: "how-prefab-financing-works",
    title: "How Prefab Home Financing Actually Works",
    description:
      "A step-by-step walkthrough of the prefab financing process, from pre-qualification to your first mortgage payment.",
    author: "Michael Chen",
    publishedAt: "2026-01-10",
    readMinutes: 8,
    category: "Financing 101",
    sections: [
      {
        heading: "Step 1: Pre-qualification",
        body: [
          "Pre-qualification takes minutes and gives you a realistic price range based on income, debt, and estimated credit tier — without a hard credit pull. This is also when we match you against lenders in our network who actively finance modular and manufactured homes in your state.",
        ],
      },
      {
        heading: "Step 2: Manufacturer and plan selection",
        body: [
          "Once pre-qualified, you'll finalize a manufacturer, floor plan, and finish package. Your lender uses the signed purchase agreement and factory specifications to order the appraisal and finalize your construction draw schedule.",
        ],
      },
      {
        heading: "Step 3: Underwriting and closing",
        body: [
          "Underwriting reviews income, assets, credit, and the appraisal simultaneously. Because construction-to-permanent loans convert automatically, you close once — locking your rate for both the build period and the permanent mortgage.",
        ],
      },
      {
        heading: "Step 4: Draws and move-in",
        body: [
          "Funds release in stages as the factory completes production milestones and the home is delivered and set on-site. After final inspection and certificate of occupancy, your loan converts to standard monthly principal-and-interest payments.",
        ],
      },
    ],
  },
];

export function getResourceBySlug(slug: string): Resource | undefined {
  return resources.find((resource) => resource.slug === slug);
}
