export interface LoanOption {
  slug: string;
  name: string;
  shortName: string;
  tagline: string;
  minDownPayment: string;
  minCreditScore: string;
  bestFor: string;
  summary: string;
  highlights: string[];
  timeline: { label: string; description: string }[];
  faqs: { question: string; answer: string }[];
}

export const loanOptions: LoanOption[] = [
  {
    slug: "conventional",
    name: "Conventional Modular Home Loans",
    shortName: "Conventional",
    tagline: "Flexible financing for factory-built homes on owned or purchased land.",
    minDownPayment: "3% – 20%",
    minCreditScore: "620+",
    bestFor: "Buyers with solid credit who already own or are purchasing land",
    summary:
      "Conventional loans are the most common path to financing a modular home once it's classified as real property. They're not backed by a government agency, so approval leans on credit score, debt-to-income ratio, and the appraised value of the finished home. Because many conventional lenders are unfamiliar with modular draw schedules, matching with a specialist lender materially speeds up underwriting.",
    highlights: [
      "As little as 3% down for qualified first-time buyers",
      "No upfront mortgage insurance premium like FHA loans",
      "Can finance land, factory build, and site work in one loan",
      "PMI cancels automatically once you reach 78% loan-to-value",
    ],
    timeline: [
      { label: "Week 1", description: "Pre-qualification and lender matching based on your credit profile" },
      { label: "Weeks 2–3", description: "Full application, land appraisal, and manufacturer contract review" },
      { label: "Weeks 4–6", description: "Underwriting, construction draw schedule setup, and closing" },
    ],
    faqs: [
      {
        question: "Can I use a conventional loan if I don't own land yet?",
        answer:
          "Yes. Conventional construction-to-permanent products can bundle land purchase, factory production, and site work into a single closing, provided the home will be permanently affixed and classified as real property.",
      },
      {
        question: "Do conventional lenders treat modular homes differently than manufactured homes?",
        answer:
          "Yes — modular homes built to state/local building codes and permanently affixed to a foundation qualify for standard conventional financing more easily than HUD-code manufactured homes, which often require chattel or specialty loans.",
      },
    ],
  },
  {
    slug: "fha",
    name: "FHA Modular Home Loans",
    shortName: "FHA",
    tagline: "Government-backed financing with a low down payment and flexible credit.",
    minDownPayment: "3.5%",
    minCreditScore: "580+",
    bestFor: "Buyers with limited savings or credit in the 580–660 range",
    summary:
      "FHA Title II loans finance modular homes the same way they finance site-built homes, since the home is permanently attached to a foundation and taxed as real property. The FHA One-Time Close construction loan is especially useful for modular buyers because it rolls the construction loan and permanent mortgage into a single closing — no re-qualifying after the home is built.",
    highlights: [
      "3.5% down payment with a 580+ credit score",
      "One-Time Close option covers factory build, delivery, and site work",
      "Seller/manufacturer can contribute up to 6% toward closing costs",
      "More flexible debt-to-income requirements than conventional loans",
    ],
    timeline: [
      { label: "Week 1", description: "Pre-qualification, FHA appraisal ordered on the proposed plan" },
      { label: "Weeks 2–4", description: "Manufacturer contract, builder license verification, plan review" },
      { label: "Weeks 5–7", description: "Loan approval, closing, first construction draw released" },
    ],
    faqs: [
      {
        question: "Does FHA require mortgage insurance?",
        answer:
          "Yes — FHA loans require an upfront mortgage insurance premium (UFMIP) plus an annual premium (MIP), which typically lasts for the life of the loan unless you refinance into a conventional product later.",
      },
      {
        question: "What is FHA One-Time Close construction financing?",
        answer:
          "It combines the construction loan and permanent mortgage into a single closing with one set of costs, which removes the risk of requalifying for a second loan after your modular home is built and set.",
      },
    ],
  },
  {
    slug: "va",
    name: "VA Modular Home Loans",
    shortName: "VA",
    tagline: "Zero-down financing for eligible veterans and active-duty service members.",
    minDownPayment: "0%",
    minCreditScore: "No VA minimum (lenders typically require 580–620)",
    bestFor: "Eligible veterans, service members, and surviving spouses",
    summary:
      "VA-backed loans let eligible borrowers finance a modular home with no down payment and no ongoing mortgage insurance. VA construction loans are less common than standard VA purchase loans, so lender selection matters — our network includes lenders who process VA one-time-close construction loans specifically for modular and prefab builds.",
    highlights: [
      "0% down payment for eligible borrowers",
      "No monthly private mortgage insurance",
      "Funding fee can be financed into the loan or waived for disability ratings",
      "Competitive fixed rates backed by a federal guaranty",
    ],
    timeline: [
      { label: "Week 1", description: "Certificate of Eligibility verification and lender matching" },
      { label: "Weeks 2–4", description: "Builder/manufacturer VA approval, plan and site review" },
      { label: "Weeks 5–8", description: "VA appraisal, underwriting, closing, and construction draws" },
    ],
    faqs: [
      {
        question: "Can I use my VA benefit for a modular home more than once?",
        answer:
          "Yes, as long as you have remaining entitlement. Many veterans restore full entitlement after paying off a prior VA loan or selling the home it was used for.",
      },
      {
        question: "Are there restrictions on the type of modular home builder?",
        answer:
          "The builder and manufacturer typically need VA-recognized status and the finished home must meet VA minimum property requirements, which our matched lenders confirm during pre-approval.",
      },
    ],
  },
  {
    slug: "usda",
    name: "USDA Modular Home Loans",
    shortName: "USDA",
    tagline: "0% down financing for modular homes in eligible rural and suburban areas.",
    minDownPayment: "0%",
    minCreditScore: "640+ typical",
    bestFor: "Moderate-income buyers building in USDA-eligible areas",
    summary:
      "USDA Rural Development loans finance modular homes with no down payment in areas the USDA designates as rural — which includes many suburban communities outside major metros. Income limits apply, and the home must be your primary residence, but the combination of 0% down and below-market guarantee fees makes USDA one of the most affordable paths to a new modular home.",
    highlights: [
      "0% down payment in eligible areas",
      "Reduced mortgage insurance compared to FHA",
      "Income limits are set by county and household size",
      "Can finance land, factory build, and site work together",
    ],
    timeline: [
      { label: "Week 1", description: "Property and income eligibility check against USDA maps" },
      { label: "Weeks 2–4", description: "Application, appraisal, and construction plan approval" },
      { label: "Weeks 5–8", description: "USDA conditional commitment, closing, construction draws" },
    ],
    faqs: [
      {
        question: "How do I know if my land qualifies?",
        answer:
          "USDA maintains an eligibility map by address. Many areas just outside city limits still qualify — your matched lender will verify the specific parcel before you commit.",
      },
      {
        question: "Is there a maximum home price for USDA financing?",
        answer:
          "USDA doesn't set a hard sales price cap, but your total loan amount is bound by county income limits and the appraised value, so affordability is assessed case by case.",
      },
    ],
  },
  {
    slug: "construction-loan",
    name: "Construction-to-Permanent Modular Loans",
    shortName: "Construction",
    tagline: "One closing that covers factory production, delivery, site work, and your permanent mortgage.",
    minDownPayment: "3% – 20% depending on program",
    minCreditScore: "620+ typical",
    bestFor: "Buyers building a custom modular home from the ground up",
    summary:
      "Construction-to-permanent loans fund your project in stages — factory deposit, production milestones, delivery, and site work — then automatically convert to a permanent mortgage once the home receives its certificate of occupancy. A single closing means a single set of closing costs and no risk of losing your rate lock between construction and permanent financing.",
    highlights: [
      "Single closing covers construction and the permanent mortgage",
      "Interest-only payments during the build period",
      "Available through conventional, FHA, VA, and USDA programs",
      "Draw schedule aligned to modular production, not site-built timelines",
    ],
    timeline: [
      { label: "Month 1", description: "Pre-qualification, manufacturer and floor plan selection" },
      { label: "Month 2", description: "Full application, construction plans submitted, appraisal ordered" },
      { label: "Month 3", description: "Loan approval, closing, first draw released to the manufacturer" },
    ],
    faqs: [
      {
        question: "Can I use FHA, VA, or USDA for a construction-to-permanent loan?",
        answer:
          "Yes — all three agencies offer construction-to-permanent options. FHA One-Time Close requires just 3.5% down, VA offers 0% down for eligible veterans, and USDA offers 0% down in eligible rural areas. Not every lender supports these programs for modular builds, which is exactly what our matching solves.",
      },
      {
        question: "How does the draw schedule work with a factory-built home?",
        answer:
          "Draws are typically released at contract signing, start of production, mid-production inspection, delivery to site, and final completion — your lender will require documentation or inspection before releasing each draw.",
      },
    ],
  },
];

export function getLoanOptionBySlug(slug: string): LoanOption | undefined {
  return loanOptions.find((option) => option.slug === slug);
}
