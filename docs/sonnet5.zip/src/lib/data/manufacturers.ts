export interface Manufacturer {
  slug: string;
  name: string;
  location: string;
  tier: "affordable" | "mid-range" | "premium";
  priceRange: string;
  homeTypes: string[];
  description: string;
}

export const manufacturerTierLabels: Record<Manufacturer["tier"], { title: string; description: string }> = {
  affordable: {
    title: "Affordable Manufacturers",
    description: "Entry-level manufactured and modular builders with the widest lender coverage.",
  },
  "mid-range": {
    title: "Mid-Range Modern Prefab",
    description: "Design-forward modular builders balancing style, efficiency, and price.",
  },
  premium: {
    title: "Premium & Luxury Prefab",
    description: "Architect-driven custom modular homes with high-end finishes.",
  },
};

export const manufacturers: Manufacturer[] = [
  {
    slug: "skyline-homes",
    name: "Skyline Homes",
    location: "Elkhart, Indiana",
    tier: "affordable",
    priceRange: "$80,000 – $180,000",
    homeTypes: ["Manufactured", "Single-Section", "Multi-Section"],
    description:
      "Now part of Skyline Champion Corporation, Skyline Homes has built manufactured and modular homes since 1951 and maintains one of the broadest dealer and lender networks in the country.",
  },
  {
    slug: "clayton-homes",
    name: "Clayton Homes",
    location: "Maryville, Tennessee",
    tier: "affordable",
    priceRange: "$70,000 – $200,000",
    homeTypes: ["Manufactured", "Modular", "Tiny Home"],
    description:
      "One of the largest home builders in the United States, Clayton Homes offers manufactured and modular lines through a nationwide retail network and its own in-house lending programs.",
  },
  {
    slug: "champion-homes",
    name: "Champion Homes",
    location: "Troy, Michigan",
    tier: "affordable",
    priceRange: "$75,000 – $190,000",
    homeTypes: ["Manufactured", "Modular"],
    description:
      "Champion Homes has produced factory-built housing for more than 60 years and operates dozens of plants across the U.S., giving lenders broad familiarity with its construction standards.",
  },
  {
    slug: "commodore-homes",
    name: "Commodore Homes",
    location: "Halifax, Pennsylvania",
    tier: "affordable",
    priceRange: "$85,000 – $210,000",
    homeTypes: ["Modular", "Manufactured"],
    description:
      "Commodore builds modular and manufactured homes for the Northeast and Mid-Atlantic, known for energy-efficient packages and strong dealer support.",
  },
  {
    slug: "kithaus",
    name: "kitHAUS",
    location: "Los Angeles, California",
    tier: "mid-range",
    priceRange: "$120,000 – $350,000",
    homeTypes: ["Studio", "ADU", "Modern Modular"],
    description:
      "kitHAUS designs prefabricated studios and modern modular structures with clean lines, large glazing, and fast on-site assembly — popular for backyard ADUs and small footprints.",
  },
  {
    slug: "nationwide-homes",
    name: "Nationwide Homes",
    location: "Martinsville, Virginia",
    tier: "mid-range",
    priceRange: "$150,000 – $500,000+",
    homeTypes: ["Modular", "Cape Cod", "Ranch"],
    description:
      "A Virginia-based modular home manufacturer with 50+ years of experience building quality custom homes, specializing in starter homes through luxury estates across the Mid-Atlantic and Southeast.",
  },
  {
    slug: "excel-homes",
    name: "Excel Homes",
    location: "Liverpool, Pennsylvania",
    tier: "mid-range",
    priceRange: "$140,000 – $420,000",
    homeTypes: ["Modular", "Colonial", "Craftsman"],
    description:
      "Excel Homes has designed and engineered modular home systems for over 40 years, supplying builders across the Northeast, Mid-Atlantic, and Midwest.",
  },
  {
    slug: "ritz-craft",
    name: "Ritz-Craft Corporation",
    location: "Mifflinburg, Pennsylvania",
    tier: "mid-range",
    priceRange: "$130,000 – $450,000",
    homeTypes: ["Modular", "Custom Modular"],
    description:
      "A family-owned modular manufacturer since 1971, Ritz-Craft is known for energy-efficient construction and a wide network of independent builders across the eastern U.S.",
  },
  {
    slug: "simplex-homes",
    name: "Simplex Homes",
    location: "Scranton, Pennsylvania",
    tier: "mid-range",
    priceRange: "$135,000 – $430,000",
    homeTypes: ["Modular", "Multi-Family"],
    description:
      "Simplex Homes has manufactured modular homes since 1972, including single-family, multi-family, and commercial modular projects delivered throughout the Northeast.",
  },
  {
    slug: "fairmont-homes",
    name: "Fairmont Homes",
    location: "Nappanee, Indiana",
    tier: "affordable",
    priceRange: "$80,000 – $190,000",
    homeTypes: ["Manufactured", "Modular"],
    description:
      "Fairmont Homes builds manufactured and modular homes distributed through independent retailers across the Midwest and beyond.",
  },
  {
    slug: "deer-valley-homebuilders",
    name: "Deer Valley Homebuilders",
    location: "Sulphur Springs, Texas",
    tier: "premium",
    priceRange: "$180,000 – $600,000+",
    homeTypes: ["Modular", "Custom", "Luxury"],
    description:
      "Deer Valley designs highly customizable modular homes with premium finish packages, popular with buyers who want site-built aesthetics without the site-built timeline.",
  },
  {
    slug: "ma-modular",
    name: "MA Modular",
    location: "Boston, Massachusetts",
    tier: "premium",
    priceRange: "$350,000 – $1,200,000+",
    homeTypes: ["Architect-Designed", "Net-Zero", "Modern"],
    description:
      "MA Modular creates architect-designed modern prefab homes with a focus on sustainable living, net-zero energy packages, and clean, minimalist aesthetics.",
  },
];

export function manufacturersByTier(tier: Manufacturer["tier"]): Manufacturer[] {
  return manufacturers.filter((manufacturer) => manufacturer.tier === tier);
}
