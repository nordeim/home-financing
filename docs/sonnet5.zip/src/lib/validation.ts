import { z } from "zod";

// Mirrors the `loan_type` and `purchase_timeline` Postgres enums in
// src/db/schema.ts — keep both in sync if the enum values change.
export const loanTypeValues = [
  "conventional",
  "fha",
  "va",
  "usda",
  "construction",
  "not_sure",
] as const;

export const timelineValues = [
  "immediately",
  "1_3_months",
  "3_6_months",
  "6_12_months",
  "just_researching",
] as const;

export const leadFormSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(2, "Enter your full name")
    .max(120, "Name is too long"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  phone: z
    .string()
    .trim()
    .min(7, "Enter a valid phone number")
    .max(20, "Phone number is too long")
    .regex(/^[0-9()+\-.\s]+$/, "Use digits, spaces, and ()+- only"),
  state: z.string().trim().min(2, "Select your state").max(56),
  homePrice: z.coerce.number().int().min(0).max(5_000_000).optional(),
  downPayment: z.coerce.number().int().min(0).max(5_000_000).optional(),
  creditScoreRange: z.string().trim().max(40).optional().or(z.literal("")),
  loanType: z.enum(loanTypeValues).default("not_sure"),
  timeline: z.enum(timelineValues).default("just_researching"),
  manufacturer: z.string().trim().max(120).optional().or(z.literal("")),
  notes: z.string().trim().max(1000).optional().or(z.literal("")),
  sourcePath: z.string().trim().max(200).default("/"),
  tcpaConsent: z.coerce.boolean().refine((value) => value === true, {
    message: "You must agree to be contacted to continue",
  }),
  // Honeypot: real users never fill this hidden field in.
  companyWebsite: z.string().max(0, "Spam detected").optional().or(z.literal("")),
});

export type LeadFormInput = z.infer<typeof leadFormSchema>;

export const subscribeSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
});
