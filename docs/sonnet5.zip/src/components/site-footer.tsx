import Link from "next/link";
import { Container } from "@/components/ui/primitives";

const columns = [
  {
    title: "Loan Options",
    links: [
      { href: "/modular-home-financing/loan-options/conventional", label: "Conventional" },
      { href: "/modular-home-financing/loan-options/fha", label: "FHA" },
      { href: "/modular-home-financing/loan-options/va", label: "VA" },
      { href: "/modular-home-financing/loan-options/usda", label: "USDA" },
      { href: "/modular-home-financing/loan-options/construction-loan", label: "Construction-to-Permanent" },
    ],
  },
  {
    title: "Explore",
    links: [
      { href: "/modular-home-financing/manufacturers", label: "Manufacturers" },
      { href: "/modular-home-financing/states", label: "Financing by State" },
      { href: "/calculator", label: "Payment Calculator" },
      { href: "/compare/modular-vs-manufactured-financing", label: "Modular vs. Manufactured" },
      { href: "/resources", label: "Resources" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about-us", label: "About Us" },
      { href: "/editorial-policy", label: "Editorial Policy" },
      { href: "/privacy-policy", label: "Privacy Policy" },
      { href: "/terms-of-service", label: "Terms of Service" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-[var(--color-border)] bg-[var(--color-brand-dark)] text-[var(--color-brand-light)]">
      <Container className="grid gap-10 py-16 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div>
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-white/10 font-display text-lg font-semibold text-white">
              M
            </span>
            <span className="font-display text-xl font-semibold text-white">ModFii</span>
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-[var(--color-brand-light)]/80">
            The first mortgage marketplace built exclusively for prefab and modular homes.
          </p>
          <p className="mt-6 text-xs leading-relaxed text-[var(--color-brand-light)]/60">
            ModFii is a mortgage marketplace, not a lender. We connect borrowers with lenders who specialize in
            modular and prefab home financing.
          </p>
        </div>

        {columns.map((column) => (
          <nav key={column.title} aria-label={column.title}>
            <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-white/70">{column.title}</h3>
            <ul className="mt-4 space-y-3">
              {column.links.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-[var(--color-brand-light)]/85 hover:text-white">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </Container>

      <div className="border-t border-white/10 py-6">
        <Container className="flex flex-col gap-2 text-xs text-[var(--color-brand-light)]/60 sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} ModFii. All rights reserved.</p>
          <p>Equal Housing Opportunity. NMLS marketplace disclosures available on request.</p>
        </Container>
      </div>
    </footer>
  );
}
