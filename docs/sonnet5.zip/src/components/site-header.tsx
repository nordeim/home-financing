"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { clsx } from "clsx";
import { Button } from "@/components/ui/button";

const navLinks = [
  { href: "/modular-home-financing", label: "Loan Options" },
  { href: "/modular-home-financing/manufacturers", label: "Manufacturers" },
  { href: "/modular-home-financing/states", label: "States" },
  { href: "/calculator", label: "Calculator" },
  { href: "/resources", label: "Resources" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--color-border)] bg-[var(--color-bg)]/95 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2" aria-label="ModFii home">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[var(--color-brand)] font-display text-lg font-semibold text-white">
            M
          </span>
          <span className="font-display text-xl font-semibold tracking-tight text-[var(--color-brand-dark)]">
            ModFii
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
          {navLinks.map((link) => {
            const active = pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={clsx(
                  "text-sm font-medium transition-colors hover:text-[var(--color-brand)]",
                  active ? "text-[var(--color-brand)]" : "text-[var(--color-ink-2)]",
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden lg:block">
          <Button href="/get-started" size="sm">
            Get pre-qualified
          </Button>
        </div>

        <button
          type="button"
          className="grid h-10 w-10 place-items-center rounded-full border border-[var(--color-border)] lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((value) => !value)}
        >
          <span className="relative block h-3.5 w-4">
            <span
              className={clsx(
                "absolute left-0 top-0 h-0.5 w-4 bg-[var(--color-ink)] transition-transform",
                open && "translate-y-[6px] rotate-45",
              )}
            />
            <span
              className={clsx(
                "absolute left-0 top-1/2 h-0.5 w-4 -translate-y-1/2 bg-[var(--color-ink)] transition-opacity",
                open && "opacity-0",
              )}
            />
            <span
              className={clsx(
                "absolute bottom-0 left-0 h-0.5 w-4 bg-[var(--color-ink)] transition-transform",
                open && "-translate-y-[6px] -rotate-45",
              )}
            />
          </span>
        </button>
      </div>

      {open ? (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-[var(--color-border)] lg:hidden">
          <ul className="mx-auto flex w-full max-w-6xl flex-col gap-1 px-6 py-4">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-lg px-3 py-3 text-sm font-medium text-[var(--color-ink-2)] hover:bg-[var(--color-bg-alt)]"
                >
                  {link.label}
                </Link>
              </li>
            ))}
            <li className="pt-2">
              <Button href="/get-started" className="w-full" onClick={() => setOpen(false)}>
                Get pre-qualified
              </Button>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  );
}
