"use client";

import { useState } from "react";
import { clsx } from "clsx";

export interface FaqItem {
  question: string;
  answer: string;
}

export function FaqAccordion({ items }: { items: FaqItem[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="divide-y divide-[var(--color-border)] rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)]">
      {items.map((item, index) => {
        const isOpen = openIndex === index;
        const panelId = `faq-panel-${index}`;
        const buttonId = `faq-button-${index}`;
        return (
          <div key={item.question}>
            <h3>
              <button
                id={buttonId}
                type="button"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left text-base font-medium text-[var(--color-ink)] hover:text-[var(--color-brand)]"
              >
                {item.question}
                <span
                  aria-hidden
                  className={clsx(
                    "grid h-7 w-7 flex-shrink-0 place-items-center rounded-full border border-[var(--color-border-strong)] text-sm transition-transform",
                    isOpen && "rotate-45 border-[var(--color-accent)] text-[var(--color-accent)]",
                  )}
                >
                  +
                </span>
              </button>
            </h3>
            <div
              id={panelId}
              role="region"
              aria-labelledby={buttonId}
              className={clsx("grid transition-all duration-200", isOpen ? "grid-rows-[1fr] pb-5" : "grid-rows-[0fr]")}
            >
              <div className="overflow-hidden px-6">
                <p className="text-sm leading-relaxed text-[var(--color-muted)]">{item.answer}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
