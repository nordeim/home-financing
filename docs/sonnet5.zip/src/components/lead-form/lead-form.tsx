"use client";

import { useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { clsx } from "clsx";
import { states } from "@/lib/data/states";
import { Button } from "@/components/ui/button";

const loanTypeOptions: { value: string; label: string }[] = [
  { value: "not_sure", label: "Not sure yet" },
  { value: "conventional", label: "Conventional" },
  { value: "fha", label: "FHA" },
  { value: "va", label: "VA" },
  { value: "usda", label: "USDA" },
  { value: "construction", label: "Construction-to-Permanent" },
];

const timelineOptions: { value: string; label: string }[] = [
  { value: "immediately", label: "Ready now" },
  { value: "1_3_months", label: "1–3 months" },
  { value: "3_6_months", label: "3–6 months" },
  { value: "6_12_months", label: "6–12 months" },
  { value: "just_researching", label: "Just researching" },
];

const creditRanges = ["Excellent (740+)", "Good (680–739)", "Fair (620–679)", "Building (below 620)", "Not sure"];

interface LeadFormProps {
  sourcePath: string;
  defaultState?: string;
  defaultLoanType?: string;
  defaultManufacturer?: string;
  heading?: string;
  subheading?: string;
}

type StepId = "home" | "profile" | "contact";

const steps: { id: StepId; label: string }[] = [
  { id: "home", label: "Home details" },
  { id: "profile", label: "Your profile" },
  { id: "contact", label: "Contact info" },
];

export function LeadForm({
  sourcePath,
  defaultState = "",
  defaultLoanType = "not_sure",
  defaultManufacturer = "",
  heading = "Get matched with a specialist lender",
  subheading = "Answer a few questions and we'll match you with lenders who finance prefab and modular homes.",
}: LeadFormProps) {
  const [stepIndex, setStepIndex] = useState(0);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const [form, setForm] = useState({
    state: defaultState,
    homePrice: "",
    downPayment: "",
    loanType: defaultLoanType,
    manufacturer: defaultManufacturer,
    creditScoreRange: "",
    timeline: "just_researching",
    fullName: "",
    email: "",
    phone: "",
    notes: "",
    tcpaConsent: false,
    companyWebsite: "",
  });

  const currentStep = steps[stepIndex]!;
  const isLastStep = stepIndex === steps.length - 1;

  const progressPercent = useMemo(() => Math.round(((stepIndex + 1) / steps.length) * 100), [stepIndex]);

  function updateField<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setFieldErrors((prev) => ({ ...prev, [key]: "" }));
  }

  function validateStep(step: StepId): boolean {
    const nextErrors: Record<string, string> = {};

    if (step === "home") {
      if (!form.state) nextErrors.state = "Select your state";
    }

    if (step === "contact") {
      if (form.fullName.trim().length < 2) nextErrors.fullName = "Enter your full name";
      if (!/^\S+@\S+\.\S+$/.test(form.email)) nextErrors.email = "Enter a valid email";
      if (form.phone.replace(/\D/g, "").length < 7) nextErrors.phone = "Enter a valid phone number";
      if (!form.tcpaConsent) nextErrors.tcpaConsent = "You must agree to be contacted to continue";
    }

    setFieldErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function handleNext() {
    if (!validateStep(currentStep.id)) return;
    setStepIndex((index) => Math.min(index + 1, steps.length - 1));
  }

  function handleBack() {
    setStepIndex((index) => Math.max(index - 1, 0));
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!validateStep("contact")) return;

    setStatus("submitting");
    setErrorMessage(null);

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: form.fullName,
          email: form.email,
          phone: form.phone,
          state: form.state,
          homePrice: form.homePrice ? Number(form.homePrice) : undefined,
          downPayment: form.downPayment ? Number(form.downPayment) : undefined,
          creditScoreRange: form.creditScoreRange,
          loanType: form.loanType,
          timeline: form.timeline,
          manufacturer: form.manufacturer,
          notes: form.notes,
          sourcePath,
          tcpaConsent: form.tcpaConsent,
          companyWebsite: form.companyWebsite,
        }),
      });

      const payload = (await response.json()) as { ok: boolean; error?: string };

      if (!response.ok || !payload.ok) {
        setStatus("error");
        setErrorMessage(payload.error ?? "Something went wrong. Please try again.");
        return;
      }

      setStatus("success");
    } catch {
      setStatus("error");
      setErrorMessage("We couldn't reach the server. Check your connection and try again.");
    }
  }

  if (status === "success") {
    return (
      <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-8 text-center shadow-[var(--shadow-soft)]">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[var(--color-brand-light)] text-2xl text-[var(--color-brand-dark)]">
          ✓
        </div>
        <h3 className="mt-4 font-display text-2xl font-medium text-[var(--color-brand-dark)]">You&apos;re on the list</h3>
        <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">
          A ModFii specialist will review your details and reach out within one business day with your matched
          lenders.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 shadow-[var(--shadow-soft)] sm:p-8">
      <div>
        <h3 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">{heading}</h3>
        <p className="mt-1 text-sm text-[var(--color-muted)]">{subheading}</p>
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          <span>
            Step {stepIndex + 1} of {steps.length}: {currentStep.label}
          </span>
          <span>{progressPercent}%</span>
        </div>
        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-[var(--color-bg-alt)]">
          <div
            className="h-full rounded-full bg-[var(--color-accent)] transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      <form className="mt-6 space-y-5" onSubmit={handleSubmit} noValidate>
        {/* Honeypot field — hidden from sighted users and assistive tech alike. */}
        <div className="hidden" aria-hidden="true">
          <label htmlFor="companyWebsite">Company website</label>
          <input
            id="companyWebsite"
            name="companyWebsite"
            tabIndex={-1}
            autoComplete="off"
            value={form.companyWebsite}
            onChange={(event) => updateField("companyWebsite", event.target.value)}
          />
        </div>

        {currentStep.id === "home" ? (
          <div className="space-y-4">
            <Field label="State" htmlFor="state" error={fieldErrors.state}>
              <select
                id="state"
                className={selectClasses}
                value={form.state}
                onChange={(event) => updateField("state", event.target.value)}
              >
                <option value="">Select a state</option>
                {states.map((state) => (
                  <option key={state.slug} value={state.name}>
                    {state.name}
                  </option>
                ))}
              </select>
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Estimated home price" htmlFor="homePrice">
                <input
                  id="homePrice"
                  inputMode="numeric"
                  placeholder="$250,000"
                  className={inputClasses}
                  value={form.homePrice}
                  onChange={(event) => updateField("homePrice", event.target.value.replace(/[^0-9]/g, ""))}
                />
              </Field>
              <Field label="Planned down payment" htmlFor="downPayment">
                <input
                  id="downPayment"
                  inputMode="numeric"
                  placeholder="$25,000"
                  className={inputClasses}
                  value={form.downPayment}
                  onChange={(event) => updateField("downPayment", event.target.value.replace(/[^0-9]/g, ""))}
                />
              </Field>
            </div>

            <Field label="Loan type" htmlFor="loanType">
              <select
                id="loanType"
                className={selectClasses}
                value={form.loanType}
                onChange={(event) => updateField("loanType", event.target.value)}
              >
                {loanTypeOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Manufacturer (optional)" htmlFor="manufacturer">
              <input
                id="manufacturer"
                placeholder="e.g. Deer Valley Homebuilders"
                className={inputClasses}
                value={form.manufacturer}
                onChange={(event) => updateField("manufacturer", event.target.value)}
              />
            </Field>
          </div>
        ) : null}

        {currentStep.id === "profile" ? (
          <div className="space-y-4">
            <Field label="Credit score range" htmlFor="creditScoreRange">
              <select
                id="creditScoreRange"
                className={selectClasses}
                value={form.creditScoreRange}
                onChange={(event) => updateField("creditScoreRange", event.target.value)}
              >
                <option value="">Select a range</option>
                {creditRanges.map((range) => (
                  <option key={range} value={range}>
                    {range}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Purchase timeline" htmlFor="timeline">
              <select
                id="timeline"
                className={selectClasses}
                value={form.timeline}
                onChange={(event) => updateField("timeline", event.target.value)}
              >
                {timelineOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Anything else we should know? (optional)" htmlFor="notes">
              <textarea
                id="notes"
                rows={3}
                className={inputClasses}
                value={form.notes}
                onChange={(event) => updateField("notes", event.target.value)}
              />
            </Field>
          </div>
        ) : null}

        {currentStep.id === "contact" ? (
          <div className="space-y-4">
            <Field label="Full name" htmlFor="fullName" error={fieldErrors.fullName}>
              <input
                id="fullName"
                autoComplete="name"
                className={inputClasses}
                value={form.fullName}
                onChange={(event) => updateField("fullName", event.target.value)}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Email" htmlFor="email" error={fieldErrors.email}>
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  className={inputClasses}
                  value={form.email}
                  onChange={(event) => updateField("email", event.target.value)}
                />
              </Field>
              <Field label="Phone" htmlFor="phone" error={fieldErrors.phone}>
                <input
                  id="phone"
                  type="tel"
                  autoComplete="tel"
                  className={inputClasses}
                  value={form.phone}
                  onChange={(event) => updateField("phone", event.target.value)}
                />
              </Field>
            </div>

            <label className="flex items-start gap-3 text-sm text-[var(--color-ink-2)]">
              <input
                type="checkbox"
                className="mt-1 h-4 w-4 rounded border-[var(--color-border-strong)] text-[var(--color-accent)]"
                checked={form.tcpaConsent}
                onChange={(event) => updateField("tcpaConsent", event.target.checked)}
              />
              <span>
                I agree to be contacted by ModFii and its network of participating lenders by phone, text, and email
                about mortgage financing, including by automated means. Consent isn&apos;t required to use ModFii.
                See our{" "}
                <a href="/privacy-policy" className="underline">
                  Privacy Policy
                </a>
                .
              </span>
            </label>
            {fieldErrors.tcpaConsent ? <p className="text-sm text-red-600">{fieldErrors.tcpaConsent}</p> : null}
          </div>
        ) : null}

        {status === "error" && errorMessage ? (
          <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
            {errorMessage}
          </p>
        ) : null}

        <div className="flex items-center justify-between gap-3 pt-2">
          {stepIndex > 0 ? (
            <Button type="button" variant="outline" size="md" onClick={handleBack}>
              Back
            </Button>
          ) : (
            <span />
          )}

          {isLastStep ? (
            <Button type="submit" size="md" disabled={status === "submitting"}>
              {status === "submitting" ? "Submitting…" : "Get matched"}
            </Button>
          ) : (
            <Button type="button" size="md" onClick={handleNext}>
              Continue
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}

const inputClasses =
  "w-full rounded-xl border border-[var(--color-border-strong)] bg-white px-4 py-2.5 text-sm text-[var(--color-ink)] outline-none transition focus:border-[var(--color-brand)] focus:ring-2 focus:ring-[var(--color-brand-light)]";
const selectClasses = inputClasses;

function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-[var(--color-ink-2)]">
        {label}
      </label>
      {children}
      {error ? <p className="mt-1 text-sm text-red-600">{error}</p> : null}
    </div>
  );
}
