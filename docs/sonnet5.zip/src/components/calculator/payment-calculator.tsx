"use client";

import { useMemo, useState } from "react";
import { formatCurrency } from "@/lib/format";

function monthlyPrincipalAndInterest(loanAmount: number, annualRatePercent: number, termYears: number): number {
  const monthlyRate = annualRatePercent / 100 / 12;
  const numPayments = termYears * 12;
  if (loanAmount <= 0) return 0;
  if (monthlyRate === 0) return loanAmount / numPayments;
  const factor = Math.pow(1 + monthlyRate, numPayments);
  return (loanAmount * monthlyRate * factor) / (factor - 1);
}

export function PaymentCalculator() {
  const [homePrice, setHomePrice] = useState(280000);
  const [downPayment, setDownPayment] = useState(28000);
  const [interestRate, setInterestRate] = useState(6.5);
  const [termYears, setTermYears] = useState(30);
  const [annualPropertyTax, setAnnualPropertyTax] = useState(2800);
  const [annualInsurance, setAnnualInsurance] = useState(1400);

  const loanAmount = Math.max(homePrice - downPayment, 0);
  const downPaymentPercent = homePrice > 0 ? (downPayment / homePrice) * 100 : 0;
  const requiresPmi = downPaymentPercent < 20 && loanAmount > 0;

  const results = useMemo(() => {
    const principalAndInterest = monthlyPrincipalAndInterest(loanAmount, interestRate, termYears);
    const monthlyTax = annualPropertyTax / 12;
    const monthlyInsurance = annualInsurance / 12;
    // Representative PMI estimate: ~0.55% of loan amount annually, common for
    // conventional loans below 20% down. Actual PMI varies by lender/credit.
    const monthlyPmi = requiresPmi ? (loanAmount * 0.0055) / 12 : 0;
    const totalMonthly = principalAndInterest + monthlyTax + monthlyInsurance + monthlyPmi;

    return { principalAndInterest, monthlyTax, monthlyInsurance, monthlyPmi, totalMonthly };
  }, [loanAmount, interestRate, termYears, annualPropertyTax, annualInsurance, requiresPmi]);

  const siteBuiltComparison = homePrice * 1.15;
  const pmiEliminationDownPayment = Math.ceil(homePrice * 0.2);

  return (
    <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
      <div className="space-y-6 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 sm:p-8">
        <SliderField
          label="Home price"
          value={homePrice}
          min={80000}
          max={900000}
          step={5000}
          format={formatCurrency}
          onChange={setHomePrice}
        />
        <SliderField
          label="Down payment"
          value={downPayment}
          min={0}
          max={Math.round(homePrice * 0.6)}
          step={1000}
          format={(v) => `${formatCurrency(v)} (${downPaymentPercent.toFixed(0)}%)`}
          onChange={setDownPayment}
        />
        <div className="grid gap-6 sm:grid-cols-2">
          <SliderField
            label="Interest rate"
            value={interestRate}
            min={3}
            max={11}
            step={0.125}
            format={(v) => `${v.toFixed(3)}%`}
            onChange={setInterestRate}
          />
          <div>
            <span className="mb-1.5 block text-sm font-medium text-[var(--color-ink-2)]">Loan term</span>
            <div className="flex gap-2">
              {[15, 20, 30].map((years) => (
                <button
                  key={years}
                  type="button"
                  onClick={() => setTermYears(years)}
                  className={`flex-1 rounded-xl border px-3 py-2.5 text-sm font-semibold transition-colors ${
                    termYears === years
                      ? "border-[var(--color-brand)] bg-[var(--color-brand)] text-white"
                      : "border-[var(--color-border-strong)] text-[var(--color-ink-2)] hover:border-[var(--color-brand)]"
                  }`}
                >
                  {years} yr
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-6 border-t border-[var(--color-border)] pt-6 sm:grid-cols-2">
          <SliderField
            label="Annual property tax"
            value={annualPropertyTax}
            min={0}
            max={20000}
            step={100}
            format={formatCurrency}
            onChange={setAnnualPropertyTax}
          />
          <SliderField
            label="Annual homeowners insurance"
            value={annualInsurance}
            min={0}
            max={8000}
            step={50}
            format={formatCurrency}
            onChange={setAnnualInsurance}
          />
        </div>
      </div>

      <div className="space-y-6">
        <div className="rounded-[var(--radius-card)] bg-[var(--color-brand)] p-8 text-white shadow-[var(--shadow-soft)]">
          <p className="text-xs font-semibold uppercase tracking-wide text-white/70">Estimated monthly payment</p>
          <p className="mt-2 font-display text-5xl font-medium">{formatCurrency(Math.round(results.totalMonthly))}</p>
          <p className="mt-1 text-sm text-white/70">/month</p>

          <dl className="mt-6 space-y-3 border-t border-white/15 pt-6 text-sm">
            <Row label="Principal & interest" value={results.principalAndInterest} />
            <Row label="Property tax" value={results.monthlyTax} />
            <Row label="Homeowners insurance" value={results.monthlyInsurance} />
            <Row label="Private mortgage insurance" value={results.monthlyPmi} />
          </dl>

          {requiresPmi ? (
            <p className="mt-6 rounded-xl bg-white/10 px-4 py-3 text-xs leading-relaxed text-white/80">
              With less than 20% down, you&apos;ll pay estimated PMI of {formatCurrency(Math.round(results.monthlyPmi))}
              /mo. Increase your down payment to {formatCurrency(pmiEliminationDownPayment)} to eliminate PMI.
            </p>
          ) : (
            <p className="mt-6 rounded-xl bg-white/10 px-4 py-3 text-xs leading-relaxed text-white/80">
              Your down payment is 20% or more, so this estimate excludes private mortgage insurance.
            </p>
          )}
        </div>

        <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
          <p className="text-sm font-semibold text-[var(--color-brand-dark)]">Modular home savings</p>
          <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">
            Modular homes typically cost 10–20% less than site-built homes of similar size. A comparable site-built
            home at this price point might run closer to{" "}
            <span className="font-semibold text-[var(--color-ink)]">{formatCurrency(Math.round(siteBuiltComparison))}</span>
            .
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-white/70">{label}</dt>
      <dd className="font-semibold">{formatCurrency(Math.round(value))}</dd>
    </div>
  );
}

function SliderField({
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  onChange: (value: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-[var(--color-ink-2)]" htmlFor={label}>
          {label}
        </label>
        <span className="text-sm font-semibold text-[var(--color-brand-dark)]">{format(value)}</span>
      </div>
      <input
        id={label}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-[var(--color-bg-alt)] accent-[var(--color-accent)]"
      />
    </div>
  );
}
