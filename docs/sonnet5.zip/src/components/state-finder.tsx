"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { states } from "@/lib/data/states";

export function StateFinder() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState("");

  const filtered = useMemo(() => {
    if (!query) return states.slice(0, 8);
    const lower = query.toLowerCase();
    return states.filter((state) => state.name.toLowerCase().includes(lower)).slice(0, 8);
  }, [query]);

  function handleGo() {
    const match = states.find((state) => state.name === selected || state.slug === selected);
    if (match) {
      router.push(`/modular-home-financing/states/${match.slug}`);
    }
  }

  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 shadow-[var(--shadow-lift)]">
      <label htmlFor="state-search" className="text-sm font-semibold text-[var(--color-ink)]">
        Find financing in your state
      </label>
      <div className="mt-3 flex flex-col gap-3 sm:flex-row">
        <input
          id="state-search"
          list="state-options"
          placeholder="Start typing a state…"
          className="w-full flex-1 rounded-xl border border-[var(--color-border-strong)] px-4 py-3 text-sm outline-none focus:border-[var(--color-brand)] focus:ring-2 focus:ring-[var(--color-brand-light)]"
          value={query}
          onChange={(event) => {
            setQuery(event.target.value);
            setSelected(event.target.value);
          }}
        />
        <datalist id="state-options">
          {filtered.map((state) => (
            <option key={state.slug} value={state.name} />
          ))}
        </datalist>
        <button
          type="button"
          onClick={handleGo}
          className="rounded-[var(--radius-pill)] bg-[var(--color-brand)] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[var(--color-brand-dark)]"
        >
          View state guide
        </button>
      </div>
    </div>
  );
}
