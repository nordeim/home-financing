import Link from "next/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { clsx } from "clsx";

type Variant = "primary" | "secondary" | "outline" | "ghost";
type Size = "sm" | "md" | "lg";

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent-dark)] shadow-[var(--shadow-lift)]",
  secondary:
    "bg-[var(--color-brand)] text-white hover:bg-[var(--color-brand-dark)] shadow-[var(--shadow-lift)]",
  outline:
    "border border-[var(--color-border-strong)] text-[var(--color-ink)] bg-transparent hover:bg-[var(--color-surface)]",
  ghost: "bg-transparent text-[var(--color-ink)] hover:bg-[var(--color-bg-alt)]",
};

const sizeClasses: Record<Size, string> = {
  sm: "px-4 py-2 text-sm",
  md: "px-5 py-3 text-sm",
  lg: "px-7 py-4 text-base",
};

const baseClasses =
  "inline-flex items-center justify-center gap-2 rounded-[var(--radius-pill)] font-semibold transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-60 whitespace-nowrap";

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: ReactNode;
}

interface ButtonAsButton extends CommonProps, Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  href?: undefined;
}

interface ButtonAsLink extends CommonProps {
  href: string;
  prefetch?: boolean;
  onClick?: () => void;
}

export function Button(props: ButtonAsButton | ButtonAsLink) {
  const { variant = "primary", size = "md", className, children } = props;
  const classes = clsx(baseClasses, variantClasses[variant], sizeClasses[size], className);

  if ("href" in props && props.href) {
    const { href, prefetch, onClick } = props;
    return (
      <Link href={href} prefetch={prefetch} onClick={onClick} className={classes}>
        {children}
      </Link>
    );
  }

  const { href: _href, ...buttonProps } = props as ButtonAsButton;
  void _href;
  return (
    <button {...buttonProps} className={classes}>
      {children}
    </button>
  );
}
