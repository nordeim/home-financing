import type { ElementType, ReactNode } from "react";
import { clsx } from "clsx";

export function Container({
  children,
  className,
  as: Component = "div",
}: {
  children: ReactNode;
  className?: string;
  as?: ElementType;
}) {
  return <Component className={clsx("mx-auto w-full max-w-6xl px-6", className)}>{children}</Component>;
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <p
      className={clsx(
        "inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[var(--color-accent-dark)]",
        className,
      )}
    >
      <span aria-hidden className="h-px w-6 bg-[var(--color-accent)]" />
      {children}
    </p>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
}: {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={clsx("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
      <h2 className="mt-3 text-balance font-display text-3xl font-medium leading-tight text-[var(--color-brand-dark)] sm:text-4xl">
        {title}
      </h2>
      {description ? <p className="mt-4 text-base leading-relaxed text-[var(--color-muted)]">{description}</p> : null}
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={clsx(
        "rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Badge({ children, tone = "brand" }: { children: ReactNode; tone?: "brand" | "accent" | "sky" }) {
  const toneClasses = {
    brand: "bg-[var(--color-brand-light)] text-[var(--color-brand-dark)]",
    accent: "bg-[var(--color-accent-light)] text-[var(--color-accent-dark)]",
    sky: "bg-[var(--color-sky-light)] text-[var(--color-sky)]",
  } as const;
  return (
    <span
      className={clsx(
        "inline-flex items-center rounded-[var(--radius-pill)] px-3 py-1 text-xs font-semibold uppercase tracking-wide",
        toneClasses[tone],
      )}
    >
      {children}
    </span>
  );
}
