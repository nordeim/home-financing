import {
  boolean,
  index,
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Leads: prospective borrowers submitted through the pre-qualification
// wizard, the calculator CTA, or any in-page "Get matched" form.
// ---------------------------------------------------------------------------

export const leadStatusEnum = pgEnum("lead_status", [
  "new",
  "contacted",
  "matched",
  "closed",
  "archived",
]);

export const loanTypeEnum = pgEnum("loan_type", [
  "conventional",
  "fha",
  "va",
  "usda",
  "construction",
  "not_sure",
]);

export const timelineEnum = pgEnum("purchase_timeline", [
  "immediately",
  "1_3_months",
  "3_6_months",
  "6_12_months",
  "just_researching",
]);

export const leads = pgTable(
  "leads",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    fullName: text("full_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone").notNull(),
    state: text("state").notNull(),
    homePrice: integer("home_price"),
    downPayment: integer("down_payment"),
    creditScoreRange: text("credit_score_range"),
    loanType: loanTypeEnum("loan_type").notNull().default("not_sure"),
    timeline: timelineEnum("timeline").notNull().default("just_researching"),
    manufacturer: text("manufacturer"),
    notes: text("notes"),
    sourcePath: text("source_path").notNull().default("/"),
    tcpaConsent: boolean("tcpa_consent").notNull().default(false),
    status: leadStatusEnum("status").notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("leads_created_at_idx").on(table.createdAt),
    index("leads_state_idx").on(table.state),
    index("leads_status_idx").on(table.status),
  ],
);

export type Lead = typeof leads.$inferSelect;
export type NewLead = typeof leads.$inferInsert;

// ---------------------------------------------------------------------------
// Newsletter / resource-hub subscribers.
// ---------------------------------------------------------------------------

export const subscribers = pgTable("subscribers", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Subscriber = typeof subscribers.$inferSelect;
