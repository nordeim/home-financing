import type { Metadata } from "next";
import Image from "next/image";
import { Container } from "@/components/ui/primitives";
import { LeadForm } from "@/components/lead-form/lead-form";

export const metadata: Metadata = {
  title: "Get Pre-Qualified",
  description:
    "Get matched with lenders who specialize in prefab and modular home financing. Free, no obligation, no hard credit pull.",
};

const trustPoints = [
  "Free to use — we're paid by lenders, never by borrowers",
  "No hard credit inquiry to get matched",
  "Lenders who understand modular and manufactured construction draws",
  "A ModFii specialist reviews every submission personally",
];

interface GetStartedPageProps {
  searchParams: Promise<{ manufacturer?: string; state?: string; loanType?: string }>;
}

export default async function GetStartedPage({ searchParams }: GetStartedPageProps) {
  const params = await searchParams;

  return (
    <main className="py-16 sm:py-20">
      <Container className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[var(--color-accent-dark)]">
            Get started
          </p>
          <h1 className="mt-3 font-display text-4xl font-medium leading-tight text-[var(--color-brand-dark)]">
            Get pre-qualified for your prefab home
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[var(--color-muted)]">
            Answer a few quick questions and we&apos;ll match you with lenders who specialize in modular and
            manufactured home financing — usually within one business day.
          </p>

          <ul className="mt-8 space-y-3">
            {trustPoints.map((point) => (
              <li key={point} className="flex items-start gap-3 text-sm text-[var(--color-ink-2)]">
                <span className="mt-0.5 text-[var(--color-brand)]" aria-hidden>
                  ✓
                </span>
                {point}
              </li>
            ))}
          </ul>

          <div className="mt-10 hidden overflow-hidden rounded-[var(--radius-card)] shadow-[var(--shadow-lift)] lg:block">
            <Image
              src="https://images.pexels.com/photos/8439647/pexels-photo-8439647.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
              alt="An advisor reviewing home financing documents with a couple"
              width={900}
              height={700}
              className="h-full w-full object-cover"
            />
          </div>
        </div>

        <LeadForm
          sourcePath="/get-started"
          heading="Start your pre-qualification"
          subheading="Takes about 2 minutes. No obligation."
          defaultManufacturer={params.manufacturer}
          defaultState={params.state}
          defaultLoanType={params.loanType}
        />
      </Container>
    </main>
  );
}
