import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  axes: ["opsz"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://modfii-clone.example.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "ModFii — Prefab & Modular Home Mortgage Marketplace",
    template: "%s | ModFii",
  },
  description:
    "ModFii connects prefab and modular home buyers with lenders who understand factory-built construction — cutting approval times by up to 50%.",
  openGraph: {
    title: "ModFii — The #1 Prefab Home Mortgage Platform",
    description:
      "Get pre-approved for your prefab home in 15 minutes. Specialized lenders, green mortgage discounts, faster approvals.",
    type: "website",
    siteName: "ModFii",
  },
  twitter: {
    card: "summary_large_image",
    title: "ModFii — The #1 Prefab Home Mortgage Platform",
    description: "Get pre-approved for your prefab home in 15 minutes.",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${inter.variable}`}>
      <body className="flex min-h-screen flex-col bg-[var(--color-bg)] font-sans text-[var(--color-ink)] antialiased">
        <SiteHeader />
        <div className="flex-1">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
