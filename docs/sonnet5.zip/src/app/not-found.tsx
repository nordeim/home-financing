import { Container } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="grid min-h-[60vh] place-items-center py-20">
      <Container className="max-w-md text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[var(--color-accent-dark)]">404</p>
        <h1 className="mt-3 font-display text-3xl font-medium text-[var(--color-brand-dark)]">
          We couldn&apos;t find that page
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-[var(--color-muted)]">
          The page you&apos;re looking for may have moved. Try heading back home or getting pre-qualified.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Button href="/" variant="outline">
            Back to home
          </Button>
          <Button href="/get-started">Get pre-qualified</Button>
        </div>
      </Container>
    </main>
  );
}
