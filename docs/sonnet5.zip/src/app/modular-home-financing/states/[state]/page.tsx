import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Badge, Container } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { LeadForm } from "@/components/lead-form/lead-form";
import { getStateBySlug, manufacturersForState, states } from "@/lib/data/states";
import { loanOptions } from "@/lib/data/loan-options";

export function generateStaticParams() {
  return states.map((state) => ({ state: state.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ state: string }>;
}): Promise<Metadata> {
  const { state: slug } = await params;
  const state = getStateBySlug(slug);
  if (!state) return { title: "State Not Found" };
  return {
    title: `Modular Home Financing in ${state.name}`,
    description: `Get financing for your modular home in ${state.name}. Compare FHA, VA, USDA, and construction loans. Find ${state.name} down payment assistance programs.`,
  };
}

export default async function StatePage({ params }: { params: Promise<{ state: string }> }) {
  const { state: slug } = await params;
  const state = getStateBySlug(slug);
  if (!state) notFound();

  const servingManufacturers = manufacturersForState(state.slug);

  return (
    <main className="py-16 sm:py-20">
      <Container className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
        <div>
          <nav aria-label="Breadcrumb" className="text-xs text-[var(--color-muted)]">
            <Link href="/modular-home-financing/states" className="hover:text-[var(--color-brand)]">
              Financing by state
            </Link>{" "}
            / {state.name}
          </nav>
          <Badge tone="sky">{state.region}</Badge>
          <h1 className="mt-4 font-display text-4xl font-medium leading-tight text-[var(--color-brand-dark)]">
            Modular Home Financing in {state.name}
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[var(--color-ink-2)]">
            Get financing for your modular home in {state.name}. Compare FHA, VA, USDA, and construction loans, and
            find {state.name} down payment assistance programs — a {state.marketNote}.
          </p>

          <section className="mt-10 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">
              {state.housingAgency}
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">
              {state.name}&apos;s state housing finance agency runs down payment assistance and first-time buyer
              programs that can be combined with FHA, VA, USDA, or conventional financing. Program terms, income
              limits, and assistance amounts change year to year — your matched lender will confirm current
              eligibility and figures for {state.name}.
            </p>
            <ul className="mt-4 space-y-2 text-sm text-[var(--color-ink-2)]">
              <li className="flex items-start gap-2">
                <span className="text-[var(--color-brand)]">✓</span> Down payment assistance programs
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[var(--color-brand)]">✓</span> First-time homebuyer programs
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[var(--color-brand)]">✓</span> Mortgage credit certificates (where available)
              </li>
            </ul>
          </section>

          <section className="mt-10">
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">
              Loan options in {state.name}
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {loanOptions
                .filter((option) => option.slug !== "construction-loan")
                .map((option) => (
                  <Link
                    key={option.slug}
                    href={`/modular-home-financing/loan-options/${option.slug}`}
                    className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 hover:border-[var(--color-brand)]"
                  >
                    <p className="font-semibold text-[var(--color-brand-dark)]">{option.shortName} Loans</p>
                    <p className="mt-1 text-xs text-[var(--color-muted)]">
                      {option.minDownPayment} down · {option.minCreditScore}
                    </p>
                  </Link>
                ))}
              <Link
                href="/modular-home-financing/loan-options/construction-loan"
                className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 hover:border-[var(--color-brand)]"
              >
                <p className="font-semibold text-[var(--color-brand-dark)]">Construction Loans</p>
                <p className="mt-1 text-xs text-[var(--color-muted)]">One-time close available</p>
              </Link>
            </div>
          </section>

          <section className="mt-10">
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">
              Manufacturers serving {state.name}
            </h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {servingManufacturers.map((manufacturer) => (
                <Link
                  key={manufacturer.slug}
                  href="/modular-home-financing/manufacturers"
                  className="rounded-[var(--radius-pill)] border border-[var(--color-border-strong)] px-4 py-2 text-sm font-medium text-[var(--color-ink-2)] hover:border-[var(--color-brand)] hover:text-[var(--color-brand)]"
                >
                  {manufacturer.name}
                </Link>
              ))}
            </div>
            <p className="mt-3 text-xs text-[var(--color-muted)]">
              These manufacturers deliver modular homes to {state.name}.
            </p>
          </section>

          <section className="mt-10 rounded-[var(--radius-card)] bg-[var(--color-brand)] p-8 text-white">
            <h2 className="font-display text-xl font-medium">
              Ready to finance your modular home in {state.name}?
            </h2>
            <p className="mt-2 text-sm text-white/80">
              Pre-qualify in 2 minutes. Get matched with lenders who specialize in {state.name} modular home
              financing.
            </p>
            <div className="mt-6">
              <Button href={`/get-started?state=${encodeURIComponent(state.name)}`} size="lg">
                Get Pre-Qualified
              </Button>
            </div>
          </section>
        </div>

        <div className="lg:sticky lg:top-24">
          <LeadForm
            sourcePath={`/modular-home-financing/states/${state.slug}`}
            defaultState={state.name}
            heading={`Get matched in ${state.name}`}
            subheading="Free to use. No obligation."
          />
        </div>
      </Container>
    </main>
  );
}
