import type { Metadata } from "next";
import Link from "next/link";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { states } from "@/lib/data/states";

export const metadata: Metadata = {
  title: "Modular Home Financing by State",
  description:
    "Find modular and prefab home financing programs, housing finance agencies, and lenders in every U.S. state.",
};

const regions: (typeof states)[number]["region"][] = ["Northeast", "South", "Midwest", "West"];

export default function StatesIndexPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Financing by state"
          title="Modular home financing, state by state"
          description="Every state runs its own housing finance agency with unique first-time buyer and down-payment-assistance programs."
        />
      </Container>

      <Container className="mt-14 space-y-12">
        {regions.map((region) => (
          <div key={region}>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">{region}</h2>
            <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-3 lg:grid-cols-4">
              {states
                .filter((state) => state.region === region)
                .map((state) => (
                  <Link
                    key={state.slug}
                    href={`/modular-home-financing/states/${state.slug}`}
                    className="text-sm text-[var(--color-ink-2)] hover:text-[var(--color-brand)] hover:underline"
                  >
                    {state.name}
                  </Link>
                ))}
            </div>
          </div>
        ))}
      </Container>
    </main>
  );
}
