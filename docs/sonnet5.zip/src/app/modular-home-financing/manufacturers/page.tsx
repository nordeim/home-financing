import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { manufacturerTierLabels, manufacturersByTier, type Manufacturer } from "@/lib/data/manufacturers";

export const metadata: Metadata = {
  title: "Prefab Home Manufacturers",
  description:
    "Connect with approved lenders for America's top modular and manufactured home builders. Find the right financing for your dream prefab home.",
};

const tiers: Manufacturer["tier"][] = ["affordable", "mid-range", "premium"];

export default function ManufacturersPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Manufacturers"
          title="Prefab Home Manufacturers"
          description="Connect with approved lenders for America's top modular and manufactured home builders. Find the right financing for your dream prefab home."
        />
      </Container>

      {tiers.map((tier) => {
        const tierManufacturers = manufacturersByTier(tier);
        const label = manufacturerTierLabels[tier];
        return (
          <Container key={tier} className="mt-16">
            <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">{label.title}</h2>
            <p className="mt-1 text-sm text-[var(--color-muted)]">{label.description}</p>

            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {tierManufacturers.map((manufacturer) => (
                <div
                  key={manufacturer.slug}
                  className="flex h-full flex-col rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6"
                >
                  <h3 className="font-display text-lg font-medium text-[var(--color-brand-dark)]">{manufacturer.name}</h3>
                  <p className="mt-1 text-xs uppercase tracking-wide text-[var(--color-muted)]">{manufacturer.location}</p>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-[var(--color-muted)]">{manufacturer.description}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {manufacturer.homeTypes.map((type) => (
                      <span
                        key={type}
                        className="rounded-[var(--radius-pill)] bg-[var(--color-bg-alt)] px-3 py-1 text-xs font-medium text-[var(--color-ink-2)]"
                      >
                        {type}
                      </span>
                    ))}
                  </div>
                  <p className="mt-4 text-sm font-semibold text-[var(--color-brand)]">{manufacturer.priceRange}</p>
                  <Button
                    href={`/get-started?manufacturer=${encodeURIComponent(manufacturer.name)}`}
                    variant="outline"
                    size="sm"
                    className="mt-5"
                  >
                    Find Approved Lenders
                  </Button>
                </div>
              ))}
            </div>
          </Container>
        );
      })}

      <Container className="mt-20 max-w-3xl rounded-[var(--radius-card)] bg-[var(--color-brand)] p-10 text-center text-white">
        <h2 className="font-display text-2xl font-medium">Can&apos;t find your manufacturer?</h2>
        <p className="mt-2 text-sm text-white/80">
          Our lender network works with hundreds of prefab manufacturers. Get pre-qualified and we&apos;ll match you
          with the right financing solution.
        </p>
        <div className="mt-6 flex justify-center">
          <Button href="/get-started" size="lg">
            Get Pre-Qualified
          </Button>
        </div>
      </Container>
    </main>
  );
}
