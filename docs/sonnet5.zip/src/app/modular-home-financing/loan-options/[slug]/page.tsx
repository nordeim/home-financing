import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Badge, Container, SectionHeading } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { FaqAccordion } from "@/components/faq-accordion";
import { getLoanOptionBySlug, loanOptions } from "@/lib/data/loan-options";

export function generateStaticParams() {
  return loanOptions.map((option) => ({ slug: option.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const option = getLoanOptionBySlug(slug);
  if (!option) return { title: "Loan Option Not Found" };
  return {
    title: option.name,
    description: option.summary,
  };
}

export default async function LoanOptionPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const option = getLoanOptionBySlug(slug);
  if (!option) notFound();

  const otherOptions = loanOptions.filter((item) => item.slug !== option.slug);

  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl">
        <nav aria-label="Breadcrumb" className="text-xs text-[var(--color-muted)]">
          <Link href="/modular-home-financing" className="hover:text-[var(--color-brand)]">
            Modular Home Financing
          </Link>{" "}
          / {option.shortName}
        </nav>
        <Badge tone="brand">{option.shortName} loan</Badge>
        <h1 className="mt-4 font-display text-4xl font-medium leading-tight text-[var(--color-brand-dark)]">
          {option.name}
        </h1>
        <p className="mt-4 text-lg leading-relaxed text-[var(--color-ink-2)]">{option.tagline}</p>

        <dl className="mt-8 grid grid-cols-3 gap-4 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 text-sm">
          <div>
            <dt className="text-xs uppercase tracking-wide text-[var(--color-muted)]">Min. down payment</dt>
            <dd className="mt-1 font-semibold text-[var(--color-brand-dark)]">{option.minDownPayment}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-[var(--color-muted)]">Min. credit score</dt>
            <dd className="mt-1 font-semibold text-[var(--color-brand-dark)]">{option.minCreditScore}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-[var(--color-muted)]">Best for</dt>
            <dd className="mt-1 font-semibold text-[var(--color-brand-dark)]">{option.bestFor}</dd>
          </div>
        </dl>

        <p className="mt-8 text-base leading-relaxed text-[var(--color-ink-2)]">{option.summary}</p>

        <h2 className="mt-10 font-display text-2xl font-medium text-[var(--color-brand-dark)]">Program highlights</h2>
        <ul className="mt-4 space-y-3">
          {option.highlights.map((highlight) => (
            <li key={highlight} className="flex items-start gap-3 text-sm text-[var(--color-ink-2)]">
              <span className="mt-0.5 text-[var(--color-brand)]" aria-hidden>
                ✓
              </span>
              {highlight}
            </li>
          ))}
        </ul>

        <h2 className="mt-10 font-display text-2xl font-medium text-[var(--color-brand-dark)]">Typical timeline</h2>
        <ol className="mt-4 space-y-4 border-l border-[var(--color-border)] pl-6">
          {option.timeline.map((phase) => (
            <li key={phase.label} className="relative">
              <span className="absolute -left-[29px] top-1 h-3 w-3 rounded-full border-2 border-[var(--color-accent)] bg-[var(--color-surface)]" />
              <p className="text-sm font-semibold text-[var(--color-brand-dark)]">{phase.label}</p>
              <p className="mt-1 text-sm text-[var(--color-muted)]">{phase.description}</p>
            </li>
          ))}
        </ol>

        <h2 className="mt-10 font-display text-2xl font-medium text-[var(--color-brand-dark)]">Frequently asked questions</h2>
        <div className="mt-4">
          <FaqAccordion items={option.faqs} />
        </div>

        <div className="mt-12 rounded-[var(--radius-card)] bg-[var(--color-brand)] p-8 text-center text-white">
          <h2 className="font-display text-2xl font-medium">Ready for {option.shortName} pre-approval?</h2>
          <p className="mt-2 text-sm text-white/80">
            Get matched with lenders experienced in {option.shortName.toLowerCase()} modular financing.
          </p>
          <div className="mt-6 flex justify-center">
            <Button href="/get-started" size="lg">
              Get Pre-Qualified
            </Button>
          </div>
        </div>
      </Container>

      <Container className="mt-16 max-w-4xl">
        <SectionHeading eyebrow="Compare" title="Other loan options" />
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {otherOptions.map((item) => (
            <Link
              key={item.slug}
              href={`/modular-home-financing/loan-options/${item.slug}`}
              className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 text-sm font-medium text-[var(--color-brand-dark)] hover:border-[var(--color-brand)]"
            >
              {item.name} →
            </Link>
          ))}
        </div>
      </Container>
    </main>
  );
}
