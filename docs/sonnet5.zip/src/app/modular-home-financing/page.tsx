import type { Metadata } from "next";
import Link from "next/link";
import { Badge, Card, Container, SectionHeading } from "@/components/ui/primitives";
import { StateFinder } from "@/components/state-finder";
import { loanOptions } from "@/lib/data/loan-options";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Modular Home Financing",
  description:
    "Compare modular and prefab home financing options — conventional, FHA, VA, USDA, and construction-to-permanent loans.",
};

export default function ModularHomeFinancingPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Modular home financing"
          title="Every loan program, explained for modular buyers"
          description="Compare down payment requirements, credit thresholds, and typical timelines across every major financing path."
        />
      </Container>

      <Container className="mt-12 grid gap-6 sm:grid-cols-2">
        {loanOptions.map((option) => (
          <Link
            key={option.slug}
            href={`/modular-home-financing/loan-options/${option.slug}`}
            className="group flex h-full flex-col rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-7 transition-shadow hover:shadow-[var(--shadow-lift)]"
          >
            <Badge tone="brand">{option.shortName}</Badge>
            <h2 className="mt-4 font-display text-xl font-medium text-[var(--color-brand-dark)] group-hover:text-[var(--color-accent-dark)]">
              {option.name}
            </h2>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-[var(--color-muted)]">{option.summary}</p>
            <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-[var(--color-border)] pt-5 text-xs text-[var(--color-ink-2)]">
              <div>
                <dt className="text-[var(--color-muted)]">Min. down</dt>
                <dd className="font-semibold">{option.minDownPayment}</dd>
              </div>
              <div>
                <dt className="text-[var(--color-muted)]">Credit</dt>
                <dd className="font-semibold">{option.minCreditScore}</dd>
              </div>
            </dl>
          </Link>
        ))}
      </Container>

      <Container className="mt-20 grid gap-10 lg:grid-cols-2 lg:items-center">
        <div>
          <SectionHeading
            eyebrow="Financing by state"
            title="Loan availability and assistance programs vary by state"
            description="Every state runs its own housing finance agency. Find the programs available where you're building."
          />
          <div className="mt-6">
            <Button href="/modular-home-financing/manufacturers" variant="outline">
              Browse manufacturers instead →
            </Button>
          </div>
        </div>
        <StateFinder />
      </Container>

      <Container className="mt-20 max-w-3xl">
        <Card className="text-center">
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">
            Not sure which loan fits your project?
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">
            Get pre-qualified and we&apos;ll recommend the right program based on your credit, budget, and timeline.
          </p>
          <div className="mt-6 flex justify-center">
            <Button href="/get-started" size="lg">
              Get Pre-Qualified
            </Button>
          </div>
        </Card>
      </Container>
    </main>
  );
}
