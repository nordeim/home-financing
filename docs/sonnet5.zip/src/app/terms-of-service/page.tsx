import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms governing your use of the ModFii mortgage marketplace.",
};

const lastUpdated = "2026-01-01";

export default function TermsOfServicePage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-2xl">
        <SectionHeading eyebrow="Legal" title="Terms of Service" />
        <p className="mt-4 text-sm text-[var(--color-muted)]">Last updated {formatDate(lastUpdated)}</p>

        <div className="mt-10 space-y-8 text-[var(--color-ink-2)]">
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">ModFii is a marketplace, not a lender</h2>
            <p className="mt-3 text-sm leading-relaxed">
              ModFii does not make loans, extend credit, or guarantee approval. We connect you with third-party
              lenders who may offer financing. Any loan is made solely between you and the lender under that
              lender&apos;s own terms.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">No guarantee of outcome</h2>
            <p className="mt-3 text-sm leading-relaxed">
              Submitting a pre-qualification request does not guarantee you will be matched with a lender or approved
              for financing. Approval, rates, and terms are determined solely by the lender based on their own
              underwriting criteria.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Acceptable use</h2>
            <p className="mt-3 text-sm leading-relaxed">
              You agree to provide accurate information and not to use ModFii for any unlawful purpose, including
              submitting requests on behalf of someone else without authorization.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Limitation of liability</h2>
            <p className="mt-3 text-sm leading-relaxed">
              ModFii provides its matching service &quot;as is&quot; without warranties of any kind. We are not liable for the
              actions, offers, or decisions of third-party lenders in our network.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Changes to these terms</h2>
            <p className="mt-3 text-sm leading-relaxed">
              We may update these terms from time to time. Continued use of ModFii after changes take effect
              constitutes acceptance of the updated terms.
            </p>
          </section>
        </div>
      </Container>
    </main>
  );
}
