"use server";

import { redirect } from "next/navigation";
import { clearAdminSessionCookie, setAdminSessionCookie, verifyAdminPassword } from "@/lib/admin-auth";
import { checkRateLimit } from "@/lib/rate-limit";

export async function loginAction(_prevState: { error?: string } | undefined, formData: FormData) {
  const password = String(formData.get("password") ?? "");

  if (!checkRateLimit(`admin-login`, 10, 5 * 60 * 1000)) {
    return { error: "Too many attempts. Please wait a few minutes and try again." };
  }

  if (!password || !verifyAdminPassword(password)) {
    return { error: "Incorrect password." };
  }

  await setAdminSessionCookie();
  redirect("/admin/leads");
}

export async function logoutAction() {
  await clearAdminSessionCookie();
  redirect("/admin/login");
}
