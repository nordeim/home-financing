import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { leads } from "@/db/schema";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import { Container } from "@/components/ui/primitives";
import { formatCurrency, formatDate } from "@/lib/format";
import { logoutAction } from "../actions";

export const metadata: Metadata = {
  title: "Lead Dashboard",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function AdminLeadsPage() {
  if (!(await isAdminAuthenticated())) {
    redirect("/admin/login");
  }

  const allLeads = await db.select().from(leads).orderBy(desc(leads.createdAt)).limit(200);

  return (
    <main className="py-12">
      <Container>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-medium text-[var(--color-brand-dark)]">Leads</h1>
            <p className="mt-1 text-sm text-[var(--color-muted)]">{allLeads.length} most recent submissions</p>
          </div>
          <form action={logoutAction}>
            <button
              type="submit"
              className="rounded-[var(--radius-pill)] border border-[var(--color-border-strong)] px-5 py-2.5 text-sm font-semibold text-[var(--color-ink)] hover:bg-[var(--color-bg-alt)]"
            >
              Sign out
            </button>
          </form>
        </div>

        <div className="mt-8 overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)]">
          <table className="w-full min-w-[900px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-[var(--color-border)] bg-[var(--color-bg-alt)] text-left text-xs uppercase tracking-wide text-[var(--color-muted)]">
                <th className="px-4 py-3">Submitted</th>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">State</th>
                <th className="px-4 py-3">Home price</th>
                <th className="px-4 py-3">Loan type</th>
                <th className="px-4 py-3">Timeline</th>
                <th className="px-4 py-3">Source</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {allLeads.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-[var(--color-muted)]">
                    No leads submitted yet.
                  </td>
                </tr>
              ) : (
                allLeads.map((lead) => (
                  <tr key={lead.id} className="border-b border-[var(--color-border)] last:border-0">
                    <td className="whitespace-nowrap px-4 py-3 text-[var(--color-ink-2)]">
                      {formatDate(lead.createdAt)}
                    </td>
                    <td className="px-4 py-3 font-medium text-[var(--color-ink)]">{lead.fullName}</td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">
                      <div>{lead.email}</div>
                      <div className="text-xs text-[var(--color-muted)]">{lead.phone}</div>
                    </td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">{lead.state}</td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">
                      {lead.homePrice ? formatCurrency(lead.homePrice) : "—"}
                    </td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">{lead.loanType}</td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">{lead.timeline}</td>
                    <td className="px-4 py-3 text-[var(--color-ink-2)]">{lead.sourcePath}</td>
                    <td className="px-4 py-3">
                      <span className="rounded-[var(--radius-pill)] bg-[var(--color-brand-light)] px-3 py-1 text-xs font-semibold text-[var(--color-brand-dark)]">
                        {lead.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Container>
    </main>
  );
}
