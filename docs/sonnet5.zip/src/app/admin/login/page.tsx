import type { Metadata } from "next";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import { redirect } from "next/navigation";
import { Container } from "@/components/ui/primitives";
import { LoginForm } from "./login-form";

export const metadata: Metadata = {
  title: "Admin Login",
  robots: { index: false, follow: false },
};

export default async function AdminLoginPage() {
  if (await isAdminAuthenticated()) {
    redirect("/admin/leads");
  }

  return (
    <main className="grid min-h-[70vh] place-items-center py-16">
      <Container className="max-w-sm">
        <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-8 shadow-[var(--shadow-soft)]">
          <h1 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">Admin sign-in</h1>
          <p className="mt-2 text-sm text-[var(--color-muted)]">Internal lead dashboard. Authorized staff only.</p>
          <LoginForm />
        </div>
      </Container>
    </main>
  );
}
