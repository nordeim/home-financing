import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { PaymentCalculator } from "@/components/calculator/payment-calculator";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Modular Home Payment Calculator",
  description:
    "Free modular home payment calculator. Estimate monthly payments for prefab and manufactured homes including principal, interest, taxes, insurance, and PMI.",
};

const faqs = [
  {
    question: "How do I calculate my modular home payment?",
    answer:
      "Enter your home price, down payment, interest rate, and loan term. The calculator automatically factors in property taxes, insurance, and PMI if applicable to give you an accurate monthly payment estimate.",
  },
  {
    question: "What is a typical interest rate for modular home loans?",
    answer:
      "Rates for modular homes financed as real property closely track standard mortgage rates, since the home is treated like a site-built home once permanently affixed. Your exact rate depends on credit, down payment, and loan program.",
  },
  {
    question: "How much down payment do I need for a modular home?",
    answer:
      "It depends on the loan program: as little as 0% for VA or eligible USDA loans, 3.5% for FHA, and typically 3–20% for conventional loans.",
  },
  {
    question: "What is PMI and when is it required?",
    answer:
      "Private mortgage insurance protects the lender when your down payment is below 20% on a conventional loan. It's calculated as a percentage of your loan amount and can be removed once you reach 20% equity.",
  },
];

export default function CalculatorPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Free tool"
          title="Modular Home Payment Calculator"
          description="Estimate your monthly payment for a modular, prefab, or manufactured home — principal, interest, taxes, insurance, and PMI included."
        />
      </Container>

      <Container className="mt-12 max-w-5xl">
        <PaymentCalculator />
      </Container>

      <Container className="mt-20 max-w-3xl">
        <SectionHeading align="center" eyebrow="FAQ" title="Frequently asked questions" />
        <dl className="mt-10 space-y-6">
          {faqs.map((faq) => (
            <div key={faq.question} className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
              <dt className="font-display text-lg font-medium text-[var(--color-brand-dark)]">{faq.question}</dt>
              <dd className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">{faq.answer}</dd>
            </div>
          ))}
        </dl>
      </Container>

      <Container className="mt-16 max-w-3xl rounded-[var(--radius-card)] bg-[var(--color-brand)] p-10 text-center text-white">
        <h2 className="font-display text-2xl font-medium">Ready to get pre-qualified?</h2>
        <p className="mt-2 text-sm text-white/80">
          Take the next step and get matched with lenders who specialize in prefab home financing.
        </p>
        <div className="mt-6 flex justify-center">
          <Button href="/get-started" variant="primary" size="lg">
            Get Pre-Qualified
          </Button>
        </div>
      </Container>
    </main>
  );
}
