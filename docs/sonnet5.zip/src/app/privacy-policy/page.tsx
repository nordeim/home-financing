import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How ModFii collects, uses, and protects the information you share with us.",
};

const lastUpdated = "2026-01-01";

export default function PrivacyPolicyPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-2xl">
        <SectionHeading eyebrow="Legal" title="Privacy Policy" />
        <p className="mt-4 text-sm text-[var(--color-muted)]">Last updated {formatDate(lastUpdated)}</p>

        <div className="mt-10 space-y-8 text-[var(--color-ink-2)]">
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Information we collect</h2>
            <p className="mt-3 text-sm leading-relaxed">
              When you submit a pre-qualification request, we collect your name, contact details, estimated home
              price, down payment, credit score range, state, loan preferences, and any notes you provide. We also
              collect standard technical data such as IP address and browser information for security and fraud
              prevention.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">How we use it</h2>
            <p className="mt-3 text-sm leading-relaxed">
              We use your information to match you with participating lenders and to communicate with you about your
              request. With your consent, participating lenders may contact you directly by phone, text, or email
              about financing options.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Sharing</h2>
            <p className="mt-3 text-sm leading-relaxed">
              We share your submission with the lenders in our network best positioned to serve your request. We do
              not sell your information to unrelated third parties.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Your choices</h2>
            <p className="mt-3 text-sm leading-relaxed">
              You may withdraw consent to be contacted at any time by contacting us. Withdrawing consent does not
              affect matches already in progress with a lender.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Data security</h2>
            <p className="mt-3 text-sm leading-relaxed">
              We apply industry-standard safeguards to protect your information, including encryption in transit and
              access controls limiting who can view submitted leads.
            </p>
          </section>
        </div>
      </Container>
    </main>
  );
}
