import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Modular vs. Manufactured Home Financing",
  description:
    "Understanding the financing differences between modular and manufactured homes can save you thousands. Compare building codes, appraisal treatment, and loan options.",
};

const rows: { label: string; modular: string; manufactured: string }[] = [
  {
    label: "Building code",
    modular: "State/local building code — same as site-built homes",
    manufactured: "Federal HUD code (24 CFR Part 3280)",
  },
  {
    label: "Typical financing",
    modular: "Conventional, FHA, VA, USDA — treated as real property",
    manufactured: "Chattel loan (home only) or real-property loan if land + home are titled together",
  },
  {
    label: "Down payment",
    modular: "0% – 20% depending on program",
    manufactured: "0% – 5% (chattel) or 3.5%+ (FHA Title I/II)",
    },
  {
    label: "Typical interest rate",
    modular: "Comparable to site-built mortgage rates",
    manufactured: "Often 1–4 points higher, especially for chattel loans",
  },
  {
    label: "Appreciation potential",
    modular: "Generally appreciates like site-built homes",
    manufactured: "Can depreciate like a vehicle, especially if titled as personal property",
  },
  {
    label: "Foundation requirement",
    modular: "Permanent foundation required for standard mortgage financing",
    manufactured: "Permanent foundation required only for real-property (not chattel) financing",
  },
];

export default function CompareModularVsManufacturedPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Compare"
          title="Modular vs. Manufactured Home Financing"
          description="Understanding the financing differences between modular and manufactured homes can save you thousands."
        />
      </Container>

      <Container className="mt-12 overflow-x-auto">
        <table className="w-full min-w-[640px] table-fixed border-collapse overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] text-sm">
          <caption className="sr-only">Comparison of modular and manufactured home financing characteristics</caption>
          <thead>
            <tr className="bg-[var(--color-bg-alt)] text-left">
              <th scope="col" className="w-1/4 px-5 py-4 font-semibold text-[var(--color-ink)]">
                Factor
              </th>
              <th scope="col" className="w-[37.5%] px-5 py-4 font-semibold text-[var(--color-brand-dark)]">
                Modular home
              </th>
              <th scope="col" className="w-[37.5%] px-5 py-4 font-semibold text-[var(--color-ink)]">
                Manufactured home
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.label} className="border-t border-[var(--color-border)] align-top">
                <th scope="row" className="px-5 py-4 font-medium text-[var(--color-ink)]">
                  {row.label}
                </th>
                <td className="px-5 py-4 text-[var(--color-ink-2)]">{row.modular}</td>
                <td className="px-5 py-4 text-[var(--color-ink-2)]">{row.manufactured}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Container>

      <Container className="mt-14 max-w-3xl space-y-6 text-[var(--color-ink-2)]">
        <div>
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">Why the distinction matters for financing</h2>
          <p className="mt-3 text-sm leading-relaxed">
            Lenders underwrite modular and manufactured homes differently because of how each is built, titled, and
            appraised. Modular homes built to state/local code and permanently affixed to a foundation are appraised
            and financed almost identically to site-built homes — which opens the door to standard conventional, FHA,
            VA, and USDA programs at mainstream rates.
          </p>
          <p className="mt-3 text-sm leading-relaxed">
            Manufactured homes built to the federal HUD code can still qualify for real-property financing, but only
            when permanently affixed to an approved foundation and the home and land are titled together. Homes
            financed as personal property (chattel loans) typically carry higher rates and shorter terms.
          </p>
        </div>
        <div>
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">Which one is right for you?</h2>
          <p className="mt-3 text-sm leading-relaxed">
            If long-term appreciation and access to the widest range of mortgage programs matter most, modular
            construction on owned land is typically the stronger financial position. If upfront affordability and
            speed to move-in matter more, a manufactured home — ideally financed as real property — can still be a
            sound choice.
          </p>
        </div>
      </Container>

      <Container className="mt-16 max-w-3xl rounded-[var(--radius-card)] bg-[var(--color-brand)] p-10 text-center text-white">
        <h2 className="font-display text-2xl font-medium">Get matched with the right lender for your build type</h2>
        <p className="mt-2 text-sm text-white/80">
          We&apos;ll route your pre-qualification to lenders who specialize in your specific home type.
        </p>
        <div className="mt-6 flex justify-center">
          <Button href="/get-started" size="lg">
            Get Pre-Qualified
          </Button>
        </div>
      </Container>
    </main>
  );
}
