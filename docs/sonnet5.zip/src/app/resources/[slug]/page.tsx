import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Badge, Container } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { getResourceBySlug, resources } from "@/lib/data/resources";
import { formatDate } from "@/lib/format";

export function generateStaticParams() {
  return resources.map((resource) => ({ slug: resource.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const resource = getResourceBySlug(slug);
  if (!resource) return { title: "Resource Not Found" };
  return { title: resource.title, description: resource.description };
}

export default async function ResourceDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const resource = getResourceBySlug(slug);
  if (!resource) notFound();

  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-2xl">
        <nav aria-label="Breadcrumb" className="text-xs text-[var(--color-muted)]">
          <Link href="/resources" className="hover:text-[var(--color-brand)]">
            Resources
          </Link>{" "}
          / {resource.category}
        </nav>
        <Badge tone="accent">{resource.category}</Badge>
        <h1 className="mt-4 font-display text-4xl font-medium leading-tight text-[var(--color-brand-dark)]">
          {resource.title}
        </h1>
        <p className="mt-4 text-sm text-[var(--color-muted)]">
          By {resource.author} · {formatDate(resource.publishedAt)} · {resource.readMinutes} min read
        </p>

        <div className="mt-10 space-y-8">
          {resource.sections.map((section) => (
            <section key={section.heading}>
              <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">{section.heading}</h2>
              {section.body.map((paragraph, index) => (
                <p key={index} className="mt-3 text-base leading-relaxed text-[var(--color-ink-2)]">
                  {paragraph}
                </p>
              ))}
            </section>
          ))}
        </div>

        <div className="mt-14 rounded-[var(--radius-card)] bg-[var(--color-brand)] p-8 text-center text-white">
          <h2 className="font-display text-xl font-medium">Ready to see what you qualify for?</h2>
          <p className="mt-2 text-sm text-white/80">Get matched with a modular-savvy lender in about two minutes.</p>
          <div className="mt-6 flex justify-center">
            <Button href="/get-started" size="lg">
              Get Pre-Qualified
            </Button>
          </div>
        </div>
      </Container>
    </main>
  );
}
