import type { Metadata } from "next";
import Link from "next/link";
import { Badge, Container, SectionHeading } from "@/components/ui/primitives";
import { resources } from "@/lib/data/resources";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = {
  title: "Resources",
  description: "Guides on prefab and modular home financing, costs, and the mortgage process.",
};

export default function ResourcesPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-3xl text-center">
        <SectionHeading
          align="center"
          eyebrow="Resources"
          title="Learn before you borrow"
          description="Straightforward guides on prefab financing, costs, and the mortgage process — written for modular home buyers."
        />
      </Container>

      <Container className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {resources.map((resource) => (
          <Link
            key={resource.slug}
            href={`/resources/${resource.slug}`}
            className="flex h-full flex-col rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 transition-shadow hover:shadow-[var(--shadow-lift)]"
          >
            <Badge tone="accent">{resource.category}</Badge>
            <h2 className="mt-4 font-display text-lg font-medium leading-snug text-[var(--color-brand-dark)]">
              {resource.title}
            </h2>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-[var(--color-muted)]">{resource.description}</p>
            <p className="mt-4 text-xs text-[var(--color-muted)]">
              {formatDate(resource.publishedAt)} · {resource.readMinutes} min read
            </p>
          </Link>
        ))}
      </Container>
    </main>
  );
}
