import { db } from "@/db";
import { leads } from "@/db/schema";
import { leadFormSchema } from "@/lib/validation";
import { checkRateLimit, getClientIp } from "@/lib/rate-limit";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const ip = getClientIp(request.headers);
  if (!checkRateLimit(`lead:${ip}`, 5, 10 * 60 * 1000)) {
    return Response.json(
      { ok: false, error: "Too many submissions. Please try again in a few minutes." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const parsed = leadFormSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { ok: false, error: "Please check the highlighted fields.", issues: parsed.error.flatten() },
      { status: 422 },
    );
  }

  if (parsed.data.companyWebsite) {
    // Honeypot tripped — silently accept-and-drop so bots don't learn.
    return Response.json({ ok: true });
  }

  const { companyWebsite: _honeypot, ...values } = parsed.data;
  void _honeypot;

  try {
    const [created] = await db
      .insert(leads)
      .values({
        fullName: values.fullName,
        email: values.email,
        phone: values.phone,
        state: values.state,
        homePrice: values.homePrice ?? null,
        downPayment: values.downPayment ?? null,
        creditScoreRange: values.creditScoreRange || null,
        loanType: values.loanType,
        timeline: values.timeline,
        manufacturer: values.manufacturer || null,
        notes: values.notes || null,
        sourcePath: values.sourcePath,
        tcpaConsent: values.tcpaConsent,
      })
      .returning({ id: leads.id });

    return Response.json({ ok: true, id: created?.id });
  } catch (error) {
    console.error("[api/leads] failed to insert lead", error);
    return Response.json({ ok: false, error: "Something went wrong. Please try again." }, { status: 500 });
  }
}

export async function GET() {
  if (!(await isAdminAuthenticated())) {
    return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const rows = await db.select().from(leads).orderBy(desc(leads.createdAt)).limit(200);
  return Response.json({ ok: true, leads: rows });
}
