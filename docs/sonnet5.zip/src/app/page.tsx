import Image from "next/image";
import Link from "next/link";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { Button } from "@/components/ui/button";
import { Badge, Card, Container, SectionHeading } from "@/components/ui/primitives";
import { LeadForm } from "@/components/lead-form/lead-form";
import { FaqAccordion } from "@/components/faq-accordion";
import { StateFinder } from "@/components/state-finder";
import { loanOptions } from "@/lib/data/loan-options";
import { manufacturers } from "@/lib/data/manufacturers";
import { states } from "@/lib/data/states";

export const dynamic = "force-dynamic";

const valueProps = [
  {
    title: "Specialized lenders",
    description:
      "Our network only includes lenders who actively underwrite modular and manufactured home construction draws.",
    icon: "🏗️",
  },
  {
    title: "Green mortgage discounts",
    description:
      "Energy-efficient prefab builds can qualify for green mortgage rate discounts and expanded borrowing limits.",
    icon: "🌱",
  },
  {
    title: "50% faster approvals",
    description:
      "Skip lenders who don't understand modular timelines — get matched with specialists from the start.",
    icon: "⚡",
  },
];

const howItWorks = [
  {
    step: "01",
    title: "Tell us about your project",
    description: "Share your state, home price range, and loan preference in a two-minute form — no hard credit pull.",
  },
  {
    step: "02",
    title: "Get matched with lenders",
    description: "We match you with vetted lenders who finance prefab and modular construction in your state.",
  },
  {
    step: "03",
    title: "Close with confidence",
    description: "Compare offers, lock your rate, and close with a lender who understands modular draw schedules.",
  },
];

const testimonials = [
  {
    quote:
      "We'd been turned down twice by lenders who didn't understand modular draw schedules. ModFii matched us with a specialist and we closed in six weeks.",
    name: "Danielle R.",
    location: "Austin, TX",
  },
  {
    quote:
      "The calculator alone saved us from over-committing on a floor plan. Getting pre-qualified took less time than ordering dinner.",
    name: "Marcus T.",
    location: "Asheville, NC",
  },
  {
    quote:
      "Our lender knew exactly how to handle the factory deposit and delivery draw. No re-explaining modular construction from scratch.",
    name: "Priya S.",
    location: "Boise, ID",
  },
];

const faqItems = [
  {
    question: "Is ModFii a lender?",
    answer:
      "No. ModFii is a mortgage marketplace — we match you with vetted, third-party lenders who specialize in prefab and modular home financing. We never charge borrowers a fee to get matched.",
  },
  {
    question: "Will checking my options affect my credit score?",
    answer:
      "Getting matched through ModFii does not require a hard credit inquiry. Your matched lender will explain their process before running any credit check.",
  },
  {
    question: "What's the difference between modular and manufactured homes?",
    answer:
      "Modular homes are built to state/local building codes and are typically financed like site-built homes once permanently affixed. Manufactured homes are built to the federal HUD code and may require chattel or specialty financing. See our full comparison for details.",
  },
  {
    question: "Do you work with buyers who haven't chosen a manufacturer yet?",
    answer:
      "Yes. Many buyers get pre-qualified before selecting a manufacturer so they know their budget going in. You can update your manufacturer and floor plan later in the process.",
  },
];

export default async function HomePage() {
  await db.execute(sql`select 1`);
  const featuredLoanOptions = loanOptions.slice(0, 4);
  const featuredManufacturers = manufacturers.slice(0, 3);
  const stateCount = states.length;

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-[var(--color-border)]">
        <Container className="grid gap-12 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:py-24">
          <div>
            <Badge tone="accent">Prefab &amp; Modular Home Financing</Badge>
            <h1 className="mt-5 text-balance font-display text-4xl font-medium leading-[1.05] text-[var(--color-brand-dark)] sm:text-5xl lg:text-6xl">
              Get pre-approved for your prefab home in 15 minutes.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-[var(--color-ink-2)]">
              Stop losing your dream prefab home to financing nightmares. ModFii connects you with lenders who
              understand modular construction — cutting approval times by up to 50%.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Button href="/get-started" size="lg">
                Get pre-qualified — free
              </Button>
              <Button href="/calculator" size="lg" variant="outline">
                Try the payment calculator
              </Button>
            </div>

            <dl className="mt-12 grid grid-cols-3 gap-6 border-t border-[var(--color-border)] pt-8">
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">Faster</dt>
                <dd className="mt-1 font-display text-2xl font-medium text-[var(--color-brand-dark)]">50%</dd>
              </div>
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">Coverage</dt>
                <dd className="mt-1 font-display text-2xl font-medium text-[var(--color-brand-dark)]">
                  {stateCount} states
                </dd>
              </div>
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">Cost to match</dt>
                <dd className="mt-1 font-display text-2xl font-medium text-[var(--color-brand-dark)]">$0</dd>
              </div>
            </dl>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-[var(--radius-card)] shadow-[var(--shadow-soft)]">
              <Image
                src="https://images.pexels.com/photos/13752348/pexels-photo-13752348.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1100"
                alt="Modern prefab home illuminated at dusk"
                width={1100}
                height={900}
                priority
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden max-w-[240px] rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4 shadow-[var(--shadow-lift)] sm:block">
              <p className="text-xs font-semibold uppercase tracking-wide text-[var(--color-accent-dark)]">
                Just matched
              </p>
              <p className="mt-1 text-sm text-[var(--color-ink-2)]">
                A buyer in Tennessee locked a 30-yr FHA rate with a modular specialist lender.
              </p>
            </div>
          </div>
        </Container>
      </section>

      {/* Value props */}
      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-6 md:grid-cols-3">
            {valueProps.map((prop) => (
              <Card key={prop.title} className="shadow-[var(--shadow-lift)]">
                <span className="text-3xl" aria-hidden>
                  {prop.icon}
                </span>
                <h3 className="mt-4 font-display text-xl font-medium text-[var(--color-brand-dark)]">{prop.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">{prop.description}</p>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      {/* How it works */}
      <section className="bg-[var(--color-bg-alt)] py-20">
        <Container>
          <SectionHeading
            eyebrow="How it works"
            title="From pre-qualification to move-in, three steps"
            description="No lender maze. We do the matching so you can focus on choosing your home."
          />
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {howItWorks.map((item) => (
              <div key={item.step} className="relative rounded-[var(--radius-card)] bg-[var(--color-surface)] p-7">
                <span className="font-display text-4xl font-medium text-[var(--color-accent)]">{item.step}</span>
                <h3 className="mt-4 font-display text-xl font-medium text-[var(--color-brand-dark)]">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">{item.description}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Loan options */}
      <section className="py-20">
        <Container>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <SectionHeading
              eyebrow="Loan options"
              title="Financing built around modular construction"
              description="Compare down payment, credit requirements, and typical timelines for every major program."
            />
            <Link
              href="/modular-home-financing"
              className="text-sm font-semibold text-[var(--color-brand)] hover:text-[var(--color-brand-dark)]"
            >
              View all loan options →
            </Link>
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featuredLoanOptions.map((option) => (
              <Link
                key={option.slug}
                href={`/modular-home-financing/loan-options/${option.slug}`}
                className="group flex h-full flex-col rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-6 transition-shadow hover:shadow-[var(--shadow-lift)]"
              >
                <Badge tone="brand">{option.shortName}</Badge>
                <h3 className="mt-4 font-display text-lg font-medium text-[var(--color-brand-dark)] group-hover:text-[var(--color-accent-dark)]">
                  {option.name}
                </h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-[var(--color-muted)]">{option.tagline}</p>
                <dl className="mt-4 space-y-1 border-t border-[var(--color-border)] pt-4 text-xs text-[var(--color-ink-2)]">
                  <div className="flex justify-between">
                    <dt>Min. down</dt>
                    <dd className="font-semibold">{option.minDownPayment}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt>Credit</dt>
                    <dd className="font-semibold">{option.minCreditScore}</dd>
                  </div>
                </dl>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      {/* Manufacturers */}
      <section className="bg-[var(--color-bg-alt)] py-20">
        <Container>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <SectionHeading
              eyebrow="Manufacturers"
              title="Financing for the builders you already trust"
              description="From affordable manufactured homes to architect-designed luxury prefab, we match financing to your builder."
            />
            <Link
              href="/modular-home-financing/manufacturers"
              className="text-sm font-semibold text-[var(--color-brand)] hover:text-[var(--color-brand-dark)]"
            >
              See all manufacturers →
            </Link>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {featuredManufacturers.map((manufacturer) => (
              <Card key={manufacturer.slug}>
                <Badge tone="sky">{manufacturer.tier === "mid-range" ? "Mid-Range" : manufacturer.tier}</Badge>
                <h3 className="mt-4 font-display text-lg font-medium text-[var(--color-brand-dark)]">
                  {manufacturer.name}
                </h3>
                <p className="mt-1 text-xs uppercase tracking-wide text-[var(--color-muted)]">
                  {manufacturer.location}
                </p>
                <p className="mt-3 text-sm leading-relaxed text-[var(--color-muted)]">{manufacturer.description}</p>
                <p className="mt-4 text-sm font-semibold text-[var(--color-brand)]">{manufacturer.priceRange}</p>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      {/* State finder */}
      <section className="py-20">
        <Container className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <SectionHeading
              eyebrow="Financing by state"
              title="Down payment assistance and lenders vary by state"
              description="Every state runs its own housing finance agency with unique first-time buyer programs. Find yours below."
            />
            <div className="mt-6 flex flex-wrap gap-2">
              {["California", "Texas", "Florida", "New York", "Tennessee", "North Carolina"].map((name) => {
                const state = states.find((s) => s.name === name);
                if (!state) return null;
                return (
                  <Link
                    key={state.slug}
                    href={`/modular-home-financing/states/${state.slug}`}
                    className="rounded-[var(--radius-pill)] border border-[var(--color-border-strong)] px-4 py-2 text-sm font-medium text-[var(--color-ink-2)] hover:border-[var(--color-brand)] hover:text-[var(--color-brand)]"
                  >
                    {name}
                  </Link>
                );
              })}
            </div>
          </div>
          <StateFinder />
        </Container>
      </section>

      {/* Testimonials */}
      <section className="bg-[var(--color-brand-dark)] py-20 text-white">
        <Container>
          <SectionHeading
            align="center"
            eyebrow="Buyer stories"
            title={<span className="text-white">Illustrative buyer experiences</span>}
            description={
              <span className="text-[var(--color-brand-light)]/80">
                Representative feedback based on the kinds of outcomes ModFii is designed to deliver.
              </span>
            }
          />
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((testimonial) => (
              <figure
                key={testimonial.name}
                className="rounded-[var(--radius-card)] border border-white/10 bg-white/5 p-6"
              >
                <blockquote className="text-sm leading-relaxed text-white/90">&ldquo;{testimonial.quote}&rdquo;</blockquote>
                <figcaption className="mt-4 text-sm font-semibold text-white">
                  {testimonial.name} <span className="font-normal text-white/60">· {testimonial.location}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </Container>
      </section>

      {/* FAQ */}
      <section className="py-20">
        <Container className="max-w-3xl">
          <SectionHeading align="center" eyebrow="FAQ" title="Answers before you get matched" />
          <div className="mt-10">
            <FaqAccordion items={faqItems} />
          </div>
        </Container>
      </section>

      {/* Final CTA */}
      <section className="border-t border-[var(--color-border)] bg-[var(--color-bg-alt)] py-20">
        <Container className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div>
            <SectionHeading
              eyebrow="Ready when you are"
              title="Get matched with a modular-savvy lender today"
              description="It takes about two minutes, there's no obligation, and it won't affect your credit score."
            />
            <ul className="mt-6 space-y-2 text-sm text-[var(--color-ink-2)]">
              <li>✓ Free to use, always</li>
              <li>✓ No hard credit pull to get matched</li>
              <li>✓ Lenders who specialize in modular draw schedules</li>
            </ul>
          </div>
          <LeadForm sourcePath="/" />
        </Container>
      </section>
    </main>
  );
}
