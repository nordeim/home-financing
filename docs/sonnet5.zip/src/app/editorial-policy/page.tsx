import type { Metadata } from "next";
import { Container, SectionHeading } from "@/components/ui/primitives";

export const metadata: Metadata = {
  title: "Editorial Policy",
  description: "How ModFii researches, writes, and maintains accuracy in its guides and lender-matching content.",
};

export default function EditorialPolicyPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="max-w-2xl">
        <SectionHeading eyebrow="Editorial policy" title="How we research and publish" />
        <div className="mt-10 space-y-8 text-[var(--color-ink-2)]">
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Independence from lenders</h2>
            <p className="mt-3 text-sm leading-relaxed">
              Our editorial team operates independently from our lending partnerships. A lender&apos;s participation in
              our network has no bearing on how we describe loan programs, manufacturers, or state assistance
              programs in our guides.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Accuracy and updates</h2>
            <p className="mt-3 text-sm leading-relaxed">
              Mortgage rates, down-payment-assistance amounts, and program eligibility rules change frequently. We
              date every guide, avoid quoting specific dollar figures as fixed facts where they change annually, and
              recommend confirming current terms with your matched lender or the relevant state housing finance
              agency before making a decision.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Sourcing</h2>
            <p className="mt-3 text-sm leading-relaxed">
              Where we reference government loan programs (FHA, VA, USDA) or state housing finance agencies, we rely
              on publicly available program guidelines. Manufacturer and pricing information reflects publicly
              available company information and is refreshed periodically — always confirm current pricing directly
              with the manufacturer.
            </p>
          </section>
          <section>
            <h2 className="font-display text-xl font-medium text-[var(--color-brand-dark)]">Corrections</h2>
            <p className="mt-3 text-sm leading-relaxed">
              If you spot an error in any guide, contact us through the details on our About page and we will review
              and correct it promptly.
            </p>
          </section>
        </div>
      </Container>
    </main>
  );
}
