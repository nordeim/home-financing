import type { MetadataRoute } from "next";
import { loanOptions } from "@/lib/data/loan-options";
import { states } from "@/lib/data/states";
import { resources } from "@/lib/data/resources";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://modfii-clone.example.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "",
    "/calculator",
    "/get-started",
    "/modular-home-financing",
    "/modular-home-financing/manufacturers",
    "/modular-home-financing/states",
    "/compare/modular-vs-manufactured-financing",
    "/resources",
    "/about-us",
    "/editorial-policy",
    "/privacy-policy",
    "/terms-of-service",
  ];

  const loanOptionRoutes = loanOptions.map((option) => `/modular-home-financing/loan-options/${option.slug}`);
  const stateRoutes = states.map((state) => `/modular-home-financing/states/${state.slug}`);
  const resourceRoutes = resources.map((resource) => `/resources/${resource.slug}`);

  const allRoutes = [...staticRoutes, ...loanOptionRoutes, ...stateRoutes, ...resourceRoutes];

  return allRoutes.map((route) => ({
    url: `${siteUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" ? "daily" : "weekly",
    priority: route === "" ? 1 : 0.6,
  }));
}
