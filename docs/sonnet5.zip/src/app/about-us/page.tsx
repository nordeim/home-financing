import type { Metadata } from "next";
import Image from "next/image";
import { Container, SectionHeading } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "About Us",
  description: "ModFii is the first mortgage marketplace built exclusively for prefab and modular homes.",
};

const stats = [
  { label: "States covered", value: "50 + D.C." },
  { label: "Manufacturer partners tracked", value: "12+" },
  { label: "Cost to get matched", value: "$0" },
];

export default function AboutUsPage() {
  return (
    <main className="py-16 sm:py-20">
      <Container className="grid gap-12 lg:grid-cols-2 lg:items-center">
        <div>
          <SectionHeading
            eyebrow="About ModFii"
            title="Built because prefab buyers deserve lenders who understand prefab"
            description="Modular and manufactured homes are financed differently from site-built homes — but most lenders and loan officers rarely handle these deals. ModFii exists to close that gap."
          />
          <div className="mt-8 grid grid-cols-3 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 text-center">
                <p className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">{stat.value}</p>
                <p className="mt-1 text-xs text-[var(--color-muted)]">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="overflow-hidden rounded-[var(--radius-card)] shadow-[var(--shadow-soft)]">
          <Image
            src="https://images.pexels.com/photos/8439647/pexels-photo-8439647.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900"
            alt="An advisor discussing financing options with clients"
            width={900}
            height={800}
            className="h-full w-full object-cover"
          />
        </div>
      </Container>

      <Container className="mt-20 max-w-3xl space-y-6 text-[var(--color-ink-2)]">
        <div>
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">Our mission</h2>
          <p className="mt-3 text-base leading-relaxed">
            Too many prefab and modular home buyers lose their dream project to financing delays — not because
            they&apos;re unqualified, but because their lender doesn&apos;t understand modular draw schedules, factory
            deposits, or manufacturer contracts. ModFii matches buyers with lenders who do this work every day,
            cutting the education gap out of the approval process.
          </p>
        </div>
        <div>
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">What we are — and aren&apos;t</h2>
          <p className="mt-3 text-base leading-relaxed">
            ModFii is a mortgage marketplace, not a lender. We don&apos;t originate loans, hold funds, or make credit
            decisions. We collect basic information about your project and route it to vetted, third-party lenders
            in our network who actively finance prefab and modular construction in your state.
          </p>
        </div>
        <div>
          <h2 className="font-display text-2xl font-medium text-[var(--color-brand-dark)]">How we&apos;re paid</h2>
          <p className="mt-3 text-base leading-relaxed">
            Matching is always free for borrowers. Participating lenders pay ModFii a referral fee only when a match
            leads to a closed loan — so our incentive is to match you with a lender who can actually get your deal
            done, not just the highest bidder.
          </p>
        </div>
      </Container>

      <Container className="mt-16 max-w-3xl rounded-[var(--radius-card)] bg-[var(--color-brand)] p-10 text-center text-white">
        <h2 className="font-display text-2xl font-medium">See what you qualify for</h2>
        <p className="mt-2 text-sm text-white/80">Free, fast, and built specifically for prefab buyers.</p>
        <div className="mt-6 flex justify-center">
          <Button href="/get-started" size="lg">
            Get Pre-Qualified
          </Button>
        </div>
      </Container>
    </main>
  );
}
